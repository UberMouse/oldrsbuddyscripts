package noeffex.concurrency;


import java.util.concurrent.Semaphore;

public abstract class Lock {
	protected Semaphore lock;

	public Lock(final int allowed) {
		lock = new Semaphore(allowed);
	}

	public Lock() {
		this(1);
	}

	/**
	 * Execute a certain Lockable object (Can return false)
	 *
	 * @param lockable The block of code to execute
	 *
	 * @return true if it executed, false if it did not
	 * */

	public abstract boolean execute(final Lockable lockable);

	/**
	 * Execute a certain Runnable object (Should only return false if it exceptions)
	 *
	 * @param runnable The block of code to execute
	 *
	 * @return true if it executed, false if it did not
	 * */

	public abstract boolean execute(final Runnable runnable);
}
