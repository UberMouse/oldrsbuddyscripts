package noeffex.concurrency;

public interface Lockable {
	
	/**
	 * The block of code to execute
	 * 
	 * @return True of success, false on not
	 * */
	
	public boolean run();
}
