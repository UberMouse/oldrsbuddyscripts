package noeffex.concurrency;

import java.lang.ref.SoftReference;
import java.util.concurrent.ConcurrentHashMap;

// a concurrent memory safe cache (its fast too)

public class SoftCache {
	private static final ConcurrentHashMap<String, SoftReference<Entry>> entries = new ConcurrentHashMap<String, SoftReference<Entry>>();
	
	public static boolean exists(final String key) {
		return entries.containsKey(key) && get(key) != null;
	}
	
	protected static Entry get(final String key) {
		if (entries.containsKey(key)) {
			return entries.get(key).get();
		}
		return null;
	}
	
	/**
	 * Primitive boolean getter
	 * @param key The key to get
	 * @return The boolean primitive
	 * */
	
	public static boolean getBoolean(final String key) {
		Object value = getValue(key);
		if (value != null) {
			return (Boolean) value;
		}
		return false;
	}
	
	/**
	 * Primitive int getter
	 * @param key The key to get
	 * @return The int primitive
	 * */
	
	public static int getInt(final String key) {
		Object value = getValue(key);
		if (value != null) {
			return (Integer) value;
		}
		return 0;
	}
	
	/**
	 * Primitive long getter
	 * @param key The key to get
	 * @return The long primitive
	 * */
	
	public static long getLong(final String key) {
		Object value = getValue(key);
		if (value != null) {
			return (Long) value;
		}
		return 0;
	}
	
	/**
	 * Generic non-primitive value getter
	 * @param key The key to get
	 * @return The generic value of the key
	 * @note Call via MinerCache.<Type>getValue(key)
	 * */
	
	public static <T> T getValue(final String key) {
		Entry entry = get(key);
		if (entry != null) {
			try {
				@SuppressWarnings("unchecked")
				T value = (T) entry.value;
				return value;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}
	
	public static void setValue(final String key, final Object[] value) {
		Entry entry = get(key);
		if (entry == null) {
			entries.put(key, new SoftReference<Entry>(new Entry(key, value)));
		} else {
			entry.value = value;
		}
	}
	
	public static void setValue(final String key, final Object value) {
		Entry entry = get(key);
		if (entry == null) {
			entries.put(key, new SoftReference<Entry>(new Entry(key, value)));
		} else {
			entry.value = value;
		}
	}
	
	protected static class Entry {
		public volatile String key;
		public volatile Object value;
		
		public Entry(final String key, final Object value) {
			this.key = key;
			this.value = value;
		}
		
		public boolean equals(final Object object) {
			if (object instanceof Entry) {
				final Entry entry = (Entry) object;
				if (key == entry.key && value == entry.value){ 
					return true;
				}
			}
			return false;
		}
	}
}
