package noeffex.concurrency;

/**
 * A semaphore-based blocking lock
 * */

public class SoftLock extends Lock {

	/**
	 * Specify the number of allowed to execute at once
	 * 
	 * @param allowed The number allowed
	 * */

	public SoftLock(final int allowed) {
		super(allowed);
	}

	/**
	 * Standard constructor
	 * */

	public SoftLock() {
		this(1);
	}

	/**
	 * Execute a block of code with a solid lock (i.e. impenetrable)
	 * 
	 * @param lockable The block of code to execute
	 * 
	 * @return true if it executed, false if it did not
	 * */

	public boolean execute(final Lockable lockable) {
		try {
			lock.acquire();
			boolean result;
			try {
				result = lockable.run();
			} catch (final Exception e) {
				e.printStackTrace();
				result = false;
			}
			lock.release();
			return result;
		} catch (final Exception e) {
			e.printStackTrace();
		}
		return false;
	}

	/**
	 * Execute a block of code with a solid lock (i.e. impenetrable)
	 * 
	 * @param runnable The block of code to execute
	 * 
	 * @return true if it executed, false if it did not
	 * */

	public boolean execute(final Runnable runnable) {
		try {
			lock.acquire();
			try {
				 runnable.run();
			} catch (final Exception e) {
				e.printStackTrace();
				return false;
			}
			lock.release();
			return true;
		} catch (final Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
}
