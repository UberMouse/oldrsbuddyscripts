package noeffex.concurrency;

/**
 * A semaphore-based non-blocking lock
 * */

public class SolidLock extends Lock {
	
	/**
	 * Specify the number of allowed to execute at once
	 * 
	 * @param allowed The number allowed
	 * */
	
	public SolidLock(final int allowed) {
		super(allowed);
	}
	
	/**
	 * Standard constructor
	 * */
	
	public SolidLock() {
		this(1);
	}
	
	/**
	 * Execute a block of code with a solid lock (i.e. impenetrable)
	 * 
	 * @param lockable The block of code to execute
	 * 
	 * @return true if it executed, false if it did not
	 * */
	
	public boolean execute(final Lockable lockable) {
		if (lock.tryAcquire()) {
			boolean result;
			try {
				result = lockable.run();
			} catch (final Exception e) {
				e.printStackTrace();
				result = false;
			}
			lock.release();
			return result;
		} else {
			return false;
		}
	}
	
	/**
	 * Execute a block of code with a solid lock (i.e. impenetrable)
	 * 
	 * @param runnable The block of code to execute
	 * 
	 * @return true if it executed, false if it did not
	 * */
	
	public boolean execute(final Runnable runnable) {
		if (lock.tryAcquire()) {
			try {
				runnable.run();
			} catch (final Exception e) {
				e.printStackTrace();
				return false;
			}
			lock.release();
			return true;
		} else {
			return false;
		}
	}
}
