package noeffex.cooker;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.*;

import javax.swing.*;
import javax.swing.event.ListDataListener;

import noeffex.cooker.plugins.CookerInfo;
import noeffex.cooker.plugins.CookerPlugin;
import com.rsbuddy.script.methods.Account;
import com.rsbuddy.script.methods.Environment;

public class CookerGUI {

	public boolean cancel = false;
	public static Object[] selectedOre = { };

	private GUI gui;
	private SettingsManager settings = new SettingsManager(Environment.getStorageDirectory() + File.separator + "fxcooker_" + Account.getName() + ".properties");

	public boolean isVisible() {
		return gui.isVisible();
	}

	public void render() {
		try {
			SwingUtilities.invokeAndWait(new Runnable() {
				public void run() {
					gui = new GUI();
					settings.add("MouseHi", gui.mouseHi);
					settings.add("MouseLo", gui.mouseLo);
					settings.add("RunEnergy", gui.runEnergy);
					settings.add("Food", gui.foodBox);
					settings.add("Location", gui.locationBox);
				}
			});
		} catch (final Exception e) {
			e.printStackTrace();
		}

		settings.load();
		try {
			SwingUtilities.invokeAndWait(new Runnable() {
				public void run() {
					gui.setVisible(true);
				}
			});
		} catch (final Exception e) {
			e.printStackTrace();
		}
	}

	public CookerPlugin getCookerPlugin() {
		final CookerInfo[] locations = Static.COOKERS;
		final Object selectedLocation = gui.locationBox.getSelectedItem();
		for (int i = 0; i < locations.length; i++) {
			if (locations[i].getName().equals(selectedLocation)) {
				try {
					return (CookerPlugin) locations[i].getPlugin().newInstance();
				} catch (final Exception e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	public int getMouseHi() {
		return gui.mouseHi.getValue();
	}

	public int getMouseLo() {
		return gui.mouseLo.getValue();
	}

	public int[] getPreRawFood() {
		final Static.EATING[] eating = Static.EATING.values();
		final Object selectedFood = gui.foodBox.getSelectedItem();
		for (int i = 0; i < eating.length; i++) {
			if (eating[i].getName().equals(selectedFood)) {
				return eating[i].getPreRawIds();
			}
		}
		return new int[] { };
	}

	public int[] getRawFood() {
		final Static.EATING[] eating = Static.EATING.values();
		final Object selectedFood = gui.foodBox.getSelectedItem();
		for (int i = 0; i < eating.length; i++) {
			if (eating[i].getName().equals(selectedFood)) {
				return eating[i].getRawIds();
			}
		}
		return new int[] { };
	}

	public int getRunEnergy() {
		return gui.runEnergy.getValue();
	}

	static JPanel newNorthPanel(JComponent component) {
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		panel.add(component);
		return panel;
	}

	static JPanel newGridBagPanel(JComponent left, JComponent right) {
		JPanel panel = new JPanel();
		GridBagLayout layout = new GridBagLayout();
	    GridBagConstraints constraints = new GridBagConstraints();
	    constraints.gridwidth = 2;
	    constraints.ipady = 10;
	    constraints.weighty = 0;
	    constraints.fill = GridBagConstraints.HORIZONTAL;
	    constraints.anchor = GridBagConstraints.NORTH;
	    layout.setConstraints(panel, constraints);
		panel.setLayout(layout);
		panel.add(left);
		panel.add(right);
		return panel;
	}

	static JPanel newCenteredPanel(JComponent component) {
		JPanel centerPanel = new JPanel();
		GridBagLayout layout = new GridBagLayout();
	    GridBagConstraints constraints = new GridBagConstraints();
	    constraints.fill = GridBagConstraints.CENTER;
	    layout.setConstraints(centerPanel, constraints);
		centerPanel.setLayout(layout);
		centerPanel.add(component);
		return centerPanel;
	}

	static JPanel newEasternPanel(JComponent component) {
		JPanel centerPanel = new JPanel();
		GridBagLayout layout = new GridBagLayout();
	    GridBagConstraints constraints = new GridBagConstraints();
	    constraints.fill = GridBagConstraints.EAST;
	    layout.setConstraints(centerPanel, constraints);
		centerPanel.setLayout(layout);
		centerPanel.add(component);
		return centerPanel;
	}

	static JPanel newGridPair(JComponent left, JComponent right) {
		JPanel pair = new JPanel();
		pair.setLayout(new GridLayout(1, 2));
		pair.add(left);
		pair.add(right);
		return pair;
	}

	class GUI extends JFrame {
		private static final long serialVersionUID = 5457717269598505338L;

		private JButton cancelButton = new JButton("Cancel");
		private JComboBox locationBox = new JComboBox(new LocationModel());
		private JLabel logo = new JLabel("<html><font align=\"center\" size=\"5\">FxCooker by NoEffex</font></html>");
		private JComboBox foodBox = new JComboBox(new FoodModel());
		private JSlider mouseHi = new JSlider(JSlider.HORIZONTAL, 1, 10, 4);
		private JSlider mouseLo = new JSlider(JSlider.HORIZONTAL, 1, 10, 1);
		private JSlider runEnergy = new JSlider(JSlider.HORIZONTAL, 10, 100, 70);
		private JButton startButton = new JButton("Start");

		public GUI() {
			setTitle("FxMiner");
			setLayout(new BorderLayout());
			add(new NorthPanel(), BorderLayout.NORTH);
			add(new CenterPanel(), BorderLayout.CENTER);
			add(new SouthPanel(), BorderLayout.SOUTH);
			setMinimumSize(new Dimension(320, 270));
			setPreferredSize(new Dimension(320, 270));
			pack();
			setLocationRelativeTo(getParent());
		}

		class GUIActionListener implements ActionListener {

			public void actionPerformed(ActionEvent event) {
				if (event.getActionCommand().equals("Start")) {
					setVisible(false);
					settings.save();
					Static.GUI_INIT = true;
				} else if (event.getActionCommand().equals("Cancel")) {
					cancel = true;
					setVisible(false);
				}
			}
		}

		class FoodModel implements ComboBoxModel {
			private Static.EATING[] food;
			private int selectedItem = 0;

			public FoodModel() {
				food = Static.EATING.values();
			}

			public int getSize() {
				return food.length;
			}

			public Object getSelectedItem() {
				return food[selectedItem].getName();
			}
			
			public void setSelectedItem(final Object object) {
				for (int i = 0; i < food.length; i++) {
					if (food[i].getName().equals(object)) {
						selectedItem = i;
					}
				}
			}

			public Object getElementAt(final int idx) {
				return food[idx].getName();
			}

			public void addListDataListener(final ListDataListener listener) {
				//lolololol
			}

			public void removeListDataListener(final ListDataListener listener) {

			}
		}

		class LocationModel implements ComboBoxModel {
			private int selectedItem = 0;
			private HashMap<Object, Integer> nameCache = new HashMap<Object, Integer>();

			public LocationModel() {
			}

			public int getSize() {
				return Static.COOKERS.length;
			}

			public Object getSelectedItem() {
				return Static.COOKERS[selectedItem].getName();
			}

			public void setSelectedItem(final Object object) {
				if (nameCache.containsKey(object)) {
					selectedItem = nameCache.get(object);
				} else {
					int count = 0;
					for (final CookerInfo cookerInfo : Static.COOKERS) {
						if (cookerInfo.getName().equals(object)) {
							selectedItem = count;
							nameCache.put(cookerInfo.getName(), count);
							break;
						}
						count++;
					}
				}
			}

			public Object getElementAt(final int idx) {
				return Static.COOKERS[idx].getName();
			}

			public void addListDataListener(final ListDataListener listener) {

			}

			public void removeListDataListener(final ListDataListener listener) {

			}
		}

		class NorthPanel extends JPanel {
			private static final long serialVersionUID = 2845396441163322882L;

			public NorthPanel() {
				setLayout(new GridLayout(1, 1));
				add(newCenteredPanel(logo));
			}
		}

		class CenterPanel extends JTabbedPane {
			private static final long serialVersionUID = -7758476937349349304L;
			private JPanel advPanel = new AdvPanel();
			private JPanel speedPanel = new SpeedPanel();
			private JPanel mainPanel = new MainPanel();

			class MainPanel extends JPanel {
				private static final long serialVersionUID = 8531227624044952401L;

				public MainPanel() {
					setLayout(new BorderLayout());
					JPanel mainPanelTop = new JPanel();
					mainPanelTop.setLayout(new GridLayout(0, 2));
					mainPanelTop.add(new JLabel("Food:"));
					mainPanelTop.add(foodBox);
					mainPanelTop.add(new JLabel("Location:"));
					mainPanelTop.add(locationBox);
					add(mainPanelTop, BorderLayout.NORTH);
				}
			}

			class SpeedPanel extends JPanel {
				private static final long serialVersionUID = -6940325752096065659L;

				class RunEnergyPanel extends JPanel {
					private static final long serialVersionUID = 5737256436086229964L;

					public RunEnergyPanel() {
						Hashtable<Integer, JLabel> labelTable = new Hashtable<Integer, JLabel>();
						labelTable.put(70, new JLabel("Normal"));
						labelTable.put(10, new JLabel("Ridiculous"));
						labelTable.put(100, new JLabel("Safe"));
						runEnergy.setMajorTickSpacing(10);
						runEnergy.setMinorTickSpacing(1);
						runEnergy.setPaintTicks(true);
						runEnergy.setPaintLabels(true);
						runEnergy.setLabelTable(labelTable);
						setLayout(new BorderLayout());
						add(newCenteredPanel(new JLabel("Run Energy")), BorderLayout.NORTH);
						add(runEnergy, BorderLayout.CENTER);
					}
				}

				class MouseLoPanel extends JPanel {
					private static final long serialVersionUID = 4733519401675616944L;

					public MouseLoPanel() {
						Hashtable<Integer, JLabel> labelTable = new Hashtable<Integer, JLabel>();
						labelTable.put(1, new JLabel("Really Fast"));
						labelTable.put(5, new JLabel("Moderate"));
						labelTable.put(10, new JLabel("Really Slow"));
						mouseLo.setMajorTickSpacing(2);
						mouseLo.setMinorTickSpacing(1);
						mouseLo.setPaintTicks(true);
						mouseLo.setPaintLabels(true);
						mouseLo.setLabelTable(labelTable);
						mouseLo.setValue(5);
						setLayout(new BorderLayout());
						add(newCenteredPanel(new JLabel("Fastest Mouse Speed")), BorderLayout.NORTH);
						add(mouseLo, BorderLayout.CENTER);
					}
				}

				class MouseHiPanel extends JPanel {
					private static final long serialVersionUID = 1101032088552116979L;

					public MouseHiPanel() {
						Hashtable<Integer, JLabel> labelTable = new Hashtable<Integer, JLabel>();
						labelTable.put(1, new JLabel("Really Fast"));
						labelTable.put(5, new JLabel("Moderate"));
						labelTable.put(10, new JLabel("Really Slow"));
						mouseHi.setMajorTickSpacing(2);
						mouseHi.setMinorTickSpacing(1);
						mouseHi.setPaintTicks(true);
						mouseHi.setPaintLabels(true);
						mouseHi.setLabelTable(labelTable);
						mouseHi.setValue(8);
						setLayout(new BorderLayout());
						add(newCenteredPanel(new JLabel("Slowest Mouse Speed")), BorderLayout.NORTH);
						add(mouseHi, BorderLayout.CENTER);
					}
				}

				public SpeedPanel() {
					setLayout(new GridLayout(0, 1));
					add(new RunEnergyPanel());
					add(new MouseLoPanel());
					add(new MouseHiPanel());
				}
			}

			class AdvPanel extends JPanel {
				private static final long serialVersionUID = -211416205958629878L;

				public AdvPanel() {
					JPanel topPanel = new JPanel();
					topPanel.setLayout(new GridLayout(0, 2));
					setLayout(new BorderLayout());
					add(topPanel, BorderLayout.NORTH);
				}
			}

			public CenterPanel() {
				setTabLayoutPolicy(JTabbedPane.SCROLL_TAB_LAYOUT);
				addTab("Main", mainPanel);
				addTab("Speed", speedPanel);
				addTab("Advanced", advPanel);
			}
		}

		class SouthPanel extends JPanel {
			private static final long serialVersionUID = 1479994492639512142L;

			public SouthPanel() {
				setLayout(new GridLayout(1, 2));
				cancelButton.setActionCommand("Cancel");
				cancelButton.addActionListener(new GUIActionListener());
				startButton.setActionCommand("Start");
				startButton.addActionListener(new GUIActionListener());
				add(cancelButton);
				add(startButton);
			}
		}
	}

	public class SettingsManager {
		private String name;
		private LinkedList<Pair> pairs = new LinkedList<Pair>();

		public SettingsManager(String name) {
			this.name = name;
		}

		private String packString(int[] arr) {
			//separate by liek /
			StringBuilder packed = new StringBuilder();
			try {
				for (int i = 0; i < arr.length; i++) {
					packed.append(Integer.toString(arr[i]));
					if (i < (arr.length - 1)) {
						packed.append("/");
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return packed.toString();
		}

		private int[] unpackString(String packed) {
			String[] values = packed.split("/");
			int[] conv = new int[values.length];
			for (int i = 0; i < values.length; i++) {
				conv[i] = Integer.parseInt(values[i]);
			}
			return conv;
		}

		public void add(String key, JComponent component) {
			pairs.add(new Pair(key, component));
		}

		public void load() {
			try {
				final File file = new File(name);
				if (!file.exists()) {
					return;
				}
				final FileReader rd = new FileReader(file);
				final Properties prop = new Properties();
				prop.load(rd);
				try {
					SwingUtilities.invokeAndWait(new Runnable() {
						public void run() {
							for (Pair pair : pairs) {
							String value = prop.getProperty(pair.key);
							if (value == null) {
								continue;
							}
							if (pair.component instanceof JComboBox) {
								((JComboBox) pair.component).setSelectedItem((Object) value);
							} else if (pair.component instanceof JCheckBox) {
								((JCheckBox) pair.component).setSelected(Boolean.parseBoolean(value));
							} else if (pair.component instanceof JTextField) {
								((JTextField) pair.component).setText(value);
							} else if (pair.component instanceof JTextArea) {
								((JTextArea) pair.component).setText(value);
							} else if (pair.component instanceof JList) {
								int[] values = unpackString(value);
								((JList) pair.component).setSelectedIndices(values);
							} else if (pair.component instanceof JSlider) {
								((JSlider) pair.component).setValue(Integer.parseInt(value));
							}
						}
						}
					});
				} catch (Exception e) {
					e.printStackTrace();
				}

				rd.close();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void save() {
			try {
				File file = new File(name);
				FileWriter wr = new FileWriter(file);
				Properties prop = new Properties();
				for (Pair pair : pairs) {
					String value = "null";
					if (pair.component instanceof JComboBox) {
						value = (String) ((JComboBox) pair.component).getSelectedItem();
					} else if (pair.component instanceof JCheckBox) {
						value = Boolean.toString(((JCheckBox) pair.component).isSelected());
					} else if (pair.component instanceof JTextField) {
						value = ((JTextField) pair.component).getText();
					} else if (pair.component instanceof JTextArea) {
						value = ((JTextArea) pair.component).getText();
					} else if (pair.component instanceof JList) {
						value = packString(((JList) pair.component).getSelectedIndices());
					} else if (pair.component instanceof JSlider) {
						value = Integer.toString(((JSlider) pair.component).getValue());
					}
					prop.setProperty(pair.key, value);
				}
				prop.store(wr, "SettingsManager by NoEffex");
				wr.close();
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}

		class Pair {
			String key;
			JComponent component;
			public Pair(String key, JComponent component) {
				this.key = key;
				this.component = component;
			}
		}
	}
}

