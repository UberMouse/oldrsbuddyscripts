package noeffex.cooker;

import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.image.BufferedImage;
import java.text.NumberFormat;
import java.util.LinkedList;
import java.util.Locale;
import java.util.concurrent.CopyOnWriteArrayList;

import com.rsbuddy.event.events.MessageEvent;
import com.rsbuddy.event.listeners.MessageListener;
import com.rsbuddy.script.methods.*;
import com.rsbuddy.script.task.Task;
import com.rsbuddy.script.util.Random;
import com.rsbuddy.script.wrappers.Widget;
import noeffex.concurrency.SoftCache;
import noeffex.cooker.plugins.states.*;
import noeffex.cooker.resources.*;
import noeffex.utils.*;
import noeffex.states.StateManager;
import noeffex.states.StateNode;

import com.rsbuddy.event.listeners.PaintListener;
import com.rsbuddy.script.ActiveScript;
import com.rsbuddy.script.Manifest;
import com.rsbuddy.script.task.LoopTask;

@Manifest(name = "FxCooker", authors = { "NoEffex" }, version = 0.1)
public class FxCooker extends ActiveScript implements PaintListener, MessageListener, MouseListener, MouseMotionListener {
	public static FxCooker reference = null;
	private static final Class<?>[] statePlugins = { RunNode.class, BankGroup.class, CloseBankGroup.class, CookingGroup.class };

	private final Manifest properties = getClass().getAnnotation(Manifest.class);
	private final long startTime = System.currentTimeMillis();

	private final InteractivePaint iPaint = new InteractivePaint();
	private final CopyOnWriteArrayList<MouseClick> mouseClicks = new CopyOnWriteArrayList<MouseClick>();
	private BufferedImage mouseImage = ResourceManager.getImage(RegularMouse.ByteArray);
	private BufferedImage mouseImageClicked = ResourceManager.getImage(ClickedMouse.ByteArray);
	private final StateManager stateManager = new StateManager(statePlugins);
	private final Timekeeper timekeeper = new Timekeeper();
	private final ExpTracker tracker = new ExpTracker();

	public boolean onStart() {
		reference = this;
		stateManager.initClasses(statePlugins);
		getContainer().submit(Static.utilThread);
		Mouse.setSpeed(6);
		Static.gui.render();
		getContainer().submit(new MouseClickTask());
		return true;
	}

	public void onFinish() {
		if ((System.currentTimeMillis() - startTime) > 500000) {
			Environment.saveScreenshot(false);
		}
	}
	
	public int loop() {
		if (Static.gui.isVisible()) {
			return 100;
		}
		if (Static.gui.cancel) {
			return -1;
		}
		if (Static.GUI_INIT) {
			Static.cooker = Static.gui.getCookerPlugin();
			Static.FOOD = Static.gui.getRawFood();
			Static.PRE_FOOD = Static.gui.getPreRawFood();
			Static.GUI_INIT = false;
			Mouse.setSpeed(Random.nextInt(Static.gui.getMouseLo(), Static.gui.getMouseHi()));
		}
		if (Static.SCRIPT_STOP) {
			return -1;
		}
		final StateNode state = stateManager.getState();
		if (state == null) {
			return 100;
		}
		getContainer().submit(state);
		if (!state.isConcurrent()) {
			try {
				state.join();
			} catch (final Exception e) {
				
			}
		}
		return 100;
	}

	public void messageReceived(final MessageEvent message) {
		if (message.getID() != MessageEvent.MESSAGE_ACTION) {
			return;
		}

		final String messageString = message.getMessage();
		if (messageString.toLowerCase().contains("manage to cook")) {
			SoftCache.setValue("numDone", SoftCache.getInt("numDone") + 1);
		}
	}

	public void onRepaint(final Graphics g) {
		//if (!startMiner) {
		//	return; // fuuuuuuuuuuuuuuuuuuuu-
		//}
		((Graphics2D) g).setRenderingHints(new RenderingHints(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON));
		int y = 0;
		Widget chatBox = Widgets.get(Game.WIDGET_CHAT_BOX);
		if (chatBox != null && chatBox.getComponent(0).getAbsLocation().y > 0) {
			Static.CHATBOX_LOCATION = chatBox.getComponent(0).getAbsLocation();
			y = chatBox.getComponent(0).getAbsLocation().y - 344;
		}
		if (Static.LOCATION != null) {
			iPaint.processEntries(y, g, Static.LOCATION);
		}
		drawMouse(g);
	}

	private void drawMouse(final Graphics g) {
		final Point mouseLocation = Mouse.getLocation();
		g.drawImage(mouseImage, mouseLocation.x - 8, mouseLocation.y - 8, null);
		for (final MouseClick click : mouseClicks) {
			if ((System.currentTimeMillis() - click.millis) > 1000) {
				mouseClicks.remove(click);
				continue;
			}
			g.drawImage(mouseImageClicked, click.location.x - 8, click.location.y - 8, null);
		}
	}

	private class MouseClick {
		public Point location;
		public long millis;

		public MouseClick(final Point location) {
			this.location = location;
			this.millis = System.currentTimeMillis();
		}

		public boolean equals(final Object object) {
			if (object instanceof MouseClick) {
				if (((MouseClick) object).millis == millis) {
					return true;
				}
			}
			return false;
		}
	}

	private class MouseClickTask extends LoopTask {
		public int loop() {
			if (Mouse.isPressed()) {
				mouseClicks.add(new MouseClick(Mouse.getLocation()));
				while (Mouse.isPressed()) {
					Task.sleep(100);
				}
			}
			return 10;
		}
	}
	
	public static class UtilThread extends LoopTask {
		private long idle = 0;
		
		public long getIdle() {
			return idle;
		}
		
		public int loop() {
			if (Players.getLocal().getAnimation() == -1) {
				idle++;
			} else {
				idle = 0;
			}
			return 10;
		}
	}

	public interface InteractiveEntry {
		public Point getRelativeLocation();

		public Dimension getSize();

		public void areaClicked();

		public boolean regardFixed();

		public int repaint(final int offset, final int panelOffset, final boolean isHighlighted, final Graphics2D g);
	}

	public abstract class AbstractInteractiveEntry implements InteractiveEntry {
		public void areaClicked() {

		}

		public boolean regardFixed() {
			return true;
		}
	}

	public class InteractivePaint {

		LinkedList<InteractiveEntry> entries = new LinkedList<InteractiveEntry>();

		public InteractivePaint() {
			entries.add(new SkillsList());
			entries.add(new MoneysList());
			entries.add(new StatusList());
			entries.add(new ExperienceBar());
		}

		public void processEntries(final int offset, final Graphics g, final Point mouseLocation) {
			int currentOffset = 0; // panel offset
			try {
				for (final InteractiveEntry entry : entries) {
					int realOffset;
					if (entry.regardFixed()) {
						realOffset = offset;
					} else {
						realOffset = 0;
					}
					final Rectangle bounds = new Rectangle(entry.getRelativeLocation().x, entry.getRelativeLocation().y + realOffset, entry.getSize().width,
							entry.getSize().height);
					currentOffset -= entry.repaint(offset, currentOffset, bounds.contains(mouseLocation), (Graphics2D) g);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

		public void mousePressed(final int offset, final MouseEvent event) {
			for (InteractiveEntry entry : entries) {
				int realOffset;
				if (entry.regardFixed()) {
					realOffset = offset;
				} else {
					realOffset = 0;
				}
				Rectangle bounds = new Rectangle(entry.getRelativeLocation().x, entry.getRelativeLocation().y + realOffset, entry.getSize().width, entry.getSize().height);
				if (bounds.contains(event.getPoint())) {
					entry.areaClicked();
				}
			}
		}

		public class StatusList extends AbstractInteractiveEntry {
			private boolean isEnabled = false;
			private BufferedImage statusImage;

			public StatusList() {
				statusImage = ResourceManager.getImage(StatusImage.ByteArray);
			}

			public Point getRelativeLocation() {
				return new Point(481 - 70, 303);
			}

			public Dimension getSize() {
				return new Dimension(35, 35);
			}

			public void areaClicked() {
				isEnabled = !isEnabled;
			}

			public int repaint(final int offset, final int panelOffset, final boolean isHighlighted, final Graphics2D g) {
				g.setRenderingHints(new RenderingHints(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON));

				g.drawImage(statusImage, null, getRelativeLocation().x, offset + getRelativeLocation().y);
				if (isEnabled || isHighlighted) {
					final int height = 43;
					final int off = offset + panelOffset + getRelativeLocation().y - height;
					g.setColor(Color.BLACK);
					g.drawRect(getRelativeLocation().x - 150 + 70, off, 150 + getSize().width - 1, height);
					Color glassyBlack = new Color(0, 0, 0, 150);
					g.setColor(glassyBlack);
					g.fillRect(getRelativeLocation().x - 150 + 70, off, 150 + getSize().width - 1, height);
					g.setColor(Color.WHITE);
					g.setFont(new Font("Calibri", 10, 10));
					int yOff = 0;
					int ySep = 10;
					g.drawString("FxCooker by NoEffex", getRelativeLocation().x - 150 + 5 + 70, off + (yOff += ySep));
					g.drawString("Version " + properties.version(), getRelativeLocation().x - 150 + 5 + 70, off + (yOff += ySep));
					g.drawString("Status: " + stateManager.getStatus(), getRelativeLocation().x - 150 + 5 + 70, off + (yOff += ySep));
					g.drawString("Time Running: " + timekeeper.getRuntimeString(), getRelativeLocation().x - 150 + 5 + 70, off + (yOff += ySep));
					return height;
				}
				return 0;
			}
		}

		public class MoneysList extends AbstractInteractiveEntry {

			private boolean isEnabled = false;
			private BufferedImage moneysImage;
			final NumberFormat comma = NumberFormat.getNumberInstance(new Locale("en", "IN"));

			public MoneysList() {
				moneysImage = ResourceManager.getImage(MoneysImage.ByteArray);
			}

			public Point getRelativeLocation() {
				return new Point(481 - 35, 303);
			}

			public Dimension getSize() {
				return new Dimension(35, 35);
			}

			public void areaClicked() {
				isEnabled = !isEnabled;
			}

			public int repaint(final int offset, final int panelOffset, final boolean isHighlighted, final Graphics2D g) {
				g.setRenderingHints(new RenderingHints(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON));

				g.drawImage(moneysImage, null, getRelativeLocation().x, offset + getRelativeLocation().y);
				if (isEnabled || isHighlighted) {
					final int height = 33;
					final int off = offset + panelOffset + getRelativeLocation().y - height;
					g.setColor(Color.BLACK);
					g.drawRect(getRelativeLocation().x - 150 + 35, off, 150 + getSize().width - 1, height);
					Color glassyBlack = new Color(0, 0, 0, 150);
					g.setColor(glassyBlack);
					g.fillRect(getRelativeLocation().x - 150 + 35, off, 150 + getSize().width - 1, height);
					g.setColor(Color.WHITE);
					g.setFont(new Font("Calibri", 10, 10));
					int yOff = 0;
					int ySep = 10;
					g.drawString("Player Idle: " + comma.format(Static.utilThread.getIdle()), getRelativeLocation().x - 150 + 5 + 35, off
							+ (yOff += ySep));
					g.drawString("Food Cooked: " + comma.format(SoftCache.getInt("numDone")), getRelativeLocation().x - 150 + 5 + 35, off + (yOff += ySep));
					g.drawString("Food Cooked/Hr: " + comma.format(timekeeper.calcPerHour(SoftCache.getInt("numDone"))), getRelativeLocation().x - 150 + 5 + 35, off
							+ (yOff += ySep));
					return height;
				}
				return 0;
			}

		}

		public class ExperienceBar extends AbstractInteractiveEntry {

			public Point getRelativeLocation() {
				return new Point(3, 303);
			}

			public Dimension getSize() {
				return new Dimension(481 - 70 - getRelativeLocation().x, 35);
			}

			public void areaClicked() {

			}

			public int repaint(final int offset, final int panelOffset, final boolean isHighlighted, final Graphics2D g) {
				int y = getRelativeLocation().y + offset;
				g.setColor(new Color(0, 0, 0, 150));
				g.fillRect(getRelativeLocation().x, y + 17, getSize().width, getSize().height - 17 - 1);
				g.setColor(new Color(150, 150, 150, 150));
				g.fillRect(getRelativeLocation().x, y, getSize().width, getSize().height - 18);
				g.setColor(Color.BLACK);
				g.drawRect(getRelativeLocation().x, y, getSize().width, getSize().height - 1);

				// progress bar thingy
				int percent = Skills.getPercentToNextLevel(Skills.COOKING);
				double width = (((double) getSize().width - 8) * (((double) percent) / 100));
				double height = getSize().height - 1 - 10;

				g.setColor(new Color(1, 1, 1, 50));
				g.fillRect(getRelativeLocation().x + 4, y + 5, getSize().width - 8, (int) height);
				g.setColor(new Color(30, 154, 255, 50));
				g.fillRect(getRelativeLocation().x + 4, y + 5, (int) width, (int) height);

				g.setFont(new Font("Calibri", 10, 10));
				// draw the % to somewhere halfway
				g.setColor(Color.WHITE);
				g.drawString("" + percent + "% to " + (Skills.getCurrentLevel(Skills.COOKING) + 1), (int) ((int) getRelativeLocation().x + (int) width / 2) + 35,
						(int) ((int) getRelativeLocation().y + offset + (int) height / 2.5) + 12);
				return 0;
			}
		}

		public class SkillsList extends AbstractInteractiveEntry {

			private boolean isEnabled = false;
			private BufferedImage skillImage;
			final NumberFormat comma = NumberFormat.getNumberInstance(new Locale("en", "IN"));

			public SkillsList() {
				skillImage = ResourceManager.getImage(SkillsImage.ByteArray);
			}

			public Point getRelativeLocation() {
				return new Point(481, 303);
			}

			public Dimension getSize() {
				return new Dimension(35, 35);
			}

			public void areaClicked() {
				isEnabled = !isEnabled;
			}

			public int repaint(final int offset, final int panelOffset, final boolean isHighlighted, final Graphics2D g) {
				g.setRenderingHints(new RenderingHints(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON));

				final int height = 43;
				final int off = offset + panelOffset + getRelativeLocation().y - height;

				long millis = System.currentTimeMillis() - timekeeper.startTime;
				final long hours = millis / (1000 * 60 * 60);
				millis -= hours * 1000 * 60 * 60;
				final long minutes = millis / (1000 * 60);
				millis -= minutes * 1000 * 60;

				long timeToLevel = 0;
				String timeToLevelFmt = "Calculating...";
				if (tracker.getExpGained(Skills.COOKING) > 0) {
					long expGainedPerHour = timekeeper.calcPerHour(tracker.getExpGained(Skills.COOKING));
					timeToLevel = (Skills.getExpToNextLevel(Skills.COOKING) * 60 / (expGainedPerHour > 0 ? expGainedPerHour : 1));
					if (timeToLevel >= 60) {
						final long thours = (int) timeToLevel / 60;
						final long tmin = (timeToLevel - (thours * 60));
						timeToLevelFmt = thours + " Hours, " + tmin + " Minutes";
					} else {
						timeToLevelFmt = timeToLevel + " Minutes";
					}
				}

				g.drawImage(skillImage, null, getRelativeLocation().x, offset + getRelativeLocation().y);
				if (isEnabled || isHighlighted) {
					g.setColor(Color.BLACK);
					g.drawRect(getRelativeLocation().x - 150, off, 150 + getSize().width - 1, height);
					Color glassyBlack = new Color(0, 0, 0, 150);
					g.setColor(glassyBlack);
					g.fillRect(getRelativeLocation().x - 150, off, 150 + getSize().width - 1, height);
					g.setColor(Color.WHITE);
					g.setFont(new Font("Calibri", 10, 10));
					int yOff = 0;
					int ySep = 10;
					g.drawString("Time To Level: " + timeToLevelFmt, getRelativeLocation().x - 150 + 5, off + (yOff += ySep));
					g.drawString("Experience Gained: " + comma.format(tracker.getExpGained(Skills.COOKING)), getRelativeLocation().x - 150 + 5, off + (yOff += ySep));
					g.drawString("Experience/Hr: " + comma.format(timekeeper.calcPerHour(tracker.getExpGained(Skills.COOKING))), getRelativeLocation().x - 150 + 5, off
							+ (yOff += ySep));
					g.drawString("Level Gained: " + comma.format(tracker.getLevelGained(Skills.COOKING)), getRelativeLocation().x - 150 + 5, off + (yOff += ySep));
					return height;
				}
				return 0;
			}
		}
	}

	public void mouseClicked(MouseEvent e) {
	}

	public void mouseDragged(MouseEvent e) {
	}

	public void mouseEntered(MouseEvent e) {
	}

	public void mouseExited(MouseEvent e) {
	}

	public void mouseMoved(MouseEvent e) {
		Static.LOCATION = e.getPoint();
	}

	public void mousePressed(MouseEvent e) {
		int y = 0;
		if (Static.CHATBOX_LOCATION != null && Static.CHATBOX_LOCATION.y > 0) {
			y = Static.CHATBOX_LOCATION.y - 344;
		}
		iPaint.mousePressed(y, e);
	}

	public void mouseReleased(MouseEvent e) {
	}
}
