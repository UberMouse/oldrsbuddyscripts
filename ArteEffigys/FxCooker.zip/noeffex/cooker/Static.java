package noeffex.cooker;

import noeffex.cooker.FxCooker.UtilThread;
import noeffex.cooker.plugins.CookerInfo;
import noeffex.cooker.plugins.CookerPlugin;
import noeffex.cooker.plugins.cookers.*;

import java.awt.*;
import java.util.Arrays;

public class Static {

	public static enum EATING {
		SHRIMP("Shrimp", new int[] { 317 }),
		SARDINE("Sardine", new int[] { 327 }),
		HERRING("Herring", new int[] { 345 }),
		ANCHOVIES("Anchovies", new int[] { 321 }),
		MACKEREL("Mackerel", new int[] { 353 }),
		TROUT("Trout", new int[] { 335 }),
		COD("Cod", new int[] { 341 }),
		PIKE("Pike", new int[] { 349 }),
		SALMON("Salmon", new int[] { 331 }),
		TUNA("Tuna", new int[] { 359 }),
		RAINBOW_FISH("Rainbow Fish", new int[] { 10138 }),
		LOBSTER("Lobster", new int[] { 377 }),
		BASS("Bass", new int[] { 363 }),
		SWORDFISH("Swordfish", new int[] { 371 }),
		MONKFISH("Monkfish", new int[] { 7944 }),
		SHARK("Shark", new int[] { 383 }),
		SEA_TURTLE("Sea Turtle", new int[] { 395 }),
		MANTA_RAY("Manta Ray", new int[] { 389 }),
		CAVEFISH("Cavefish", new int[] { 15264 }),
		ROCKTAIL("Rocktail", new int[] { 15270 });

		private String name;
		private int[] preRawIds;
		private int[] rawIds;

		EATING(final String name, final int[] preRawIds, final int[] rawIds) {
			this.name = name;
			this.preRawIds = preRawIds;
			this.rawIds = rawIds;
		}

		EATING(final String name, final int[] rawIds) {
			this(name, new int[] { }, rawIds);
		}

		public String getName() {
			return name;
		}

		public int[] getPreRawIds() {
			return preRawIds;
		}

		public int[] getRawIds() {
			return rawIds;
		}

		public String toString() {
			return name + " - " + Arrays.toString(preRawIds) + " - " + Arrays.toString(rawIds);
		}
	}

	public static CookerPlugin cooker = new Catherby();
	public static CookerGUI gui = new CookerGUI();
	public static UtilThread utilThread = new UtilThread();

	public static Point CHATBOX_LOCATION = new Point(0, 0);
	public static final CookerInfo[] COOKERS = new CookerInfo[] { new CookerInfo(Catherby.class), new CookerInfo(Edgeville.class), new CookerInfo(NedsHouse.class), new CookerInfo(RoguesDen.class) };
	public static int[] FOOD = { 359 };
	public static boolean GUI_INIT = false;
	public static Point LOCATION = new Point(0, 0);
	public static int[] PRE_FOOD = { };
	public static boolean SCRIPT_STOP = false;
}
