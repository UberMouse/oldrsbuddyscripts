package noeffex.cooker.plugins;

public class CookerInfo {
	private String name;
	private Class<?> plugin;

	public CookerInfo(final Class<?> plugin) {
		final CookerManifest manifest = plugin.getAnnotation(CookerManifest.class);
		if (manifest != null) {
			name = manifest.name();
			System.out.println("new CookerInfo: " + name);
		} else {
			name = "(null)";
		}
		this.plugin = plugin;
	}

	/**
	 * Get the name of the plugin
	 * 
	 * @return the name of the plugin
	 * */

	public String getName() {
		return name;
	}

	/**
	 * Get the actual plugin class
	 *
	 * @return the Class<?> of the plugin
	 * */

	public Class<?> getPlugin() {
		return plugin;
	}

	public String toString() {
		return name;
	}
}
