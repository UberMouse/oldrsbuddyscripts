package noeffex.cooker.plugins;

import com.rsbuddy.script.methods.Calculations;
import com.rsbuddy.script.methods.Mouse;
import com.rsbuddy.script.wrappers.Area;
import com.rsbuddy.script.wrappers.GameObject;
import com.rsbuddy.script.wrappers.LocalPath;
import com.rsbuddy.script.wrappers.Tile;
import noeffex.cooker.utils.CookerUtils;

import java.awt.*;

public abstract class CookerPlugin {
	private static final int DEFAULT_COOK_TIMEOUT = 100;
	private static final int MOUSE_DIST_THRESHOLD = 30;

	public boolean traverseBank() {
		return new LocalPath(getBankTile()).traverse();
	}
	
	public boolean traverseCook() {
		final Tile cookingTile = getCookingTile();
		if (Calculations.isTileOnScreen(cookingTile)) {
			final Point screenPoint = Calculations.tileToScreen(cookingTile);
			Mouse.move(screenPoint, MOUSE_DIST_THRESHOLD, MOUSE_DIST_THRESHOLD);
			Point newScreenPoint = Calculations.tileToScreen(cookingTile);
			if (CookerUtils.distanceBetween(Mouse.getLocation(), newScreenPoint) <= MOUSE_DIST_THRESHOLD) {
				Mouse.click(true);
				return true;
			} else {
				return false;
			}
		} else if (Calculations.isTileOnMap(cookingTile)) {
			return cookingTile.clickOnMap();
		} else {
			return new LocalPath(getCookingTile()).traverse();
		}
	}

	public int getCookTimeout() {
		return DEFAULT_COOK_TIMEOUT;
	}
	
	public abstract Area getBankArea();
	public abstract Area getCookingArea();
	
	public abstract Tile getBankTile();
	public abstract Tile getCookingTile();
	
	public abstract GameObject getGameObject();
	
	public String getGameObjectName() {
		final GameObject object = getGameObject();
		if (object != null && object.getDef().getName() != null) {
			return object.getDef().getName();
		} else {
			return "null";
		}
	}
	
	public boolean isDepositBox() {
		return false;
	}
}
