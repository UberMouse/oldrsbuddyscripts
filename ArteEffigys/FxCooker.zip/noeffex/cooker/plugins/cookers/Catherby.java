package noeffex.cooker.plugins.cookers;

import noeffex.cooker.plugins.CookerManifest;
import noeffex.cooker.plugins.CookerPlugin;

import com.rsbuddy.script.methods.Calculations;
import com.rsbuddy.script.methods.Objects;
import com.rsbuddy.script.methods.Players;
import com.rsbuddy.script.task.Task;
import com.rsbuddy.script.util.Filter;
import com.rsbuddy.script.wrappers.Area;
import com.rsbuddy.script.wrappers.GameObject;
import com.rsbuddy.script.wrappers.LocalPath;
import com.rsbuddy.script.wrappers.Tile;

@CookerManifest(name="Catherby")
public class Catherby extends CookerPlugin {
	private static final int[] objects = { 2728 };
	private static final Area BANK_AREA = new Area(2806, 3438, 2812, 3441);
	private static final Tile BANK_TILE = new Tile(2809, 3441);
	private static final Area COOKING_AREA = new Area(2815, 3439, 2818, 3444);
	private static final Tile COOKING_TILE = new Tile(2817, 3443);
	private static final int DOOR_ID = 1530;
	private static final Tile DOOR_TILE = new Tile(2816, 3439);
	
	// awesome tiles
	private static final Tile DOOR_FRONT = new Tile(2816, 3438);
	
	private static final Filter<GameObject> DOOR = new Filter<GameObject>() {
		public boolean accept(final GameObject object) {
			if (object == null) {
				return false;
			}
			if (object.getId() == DOOR_ID && object.getLocation().equals(DOOR_FRONT)) {
				return true;
			}
			return false;
		}
	};

	public Area getBankArea() {
		return BANK_AREA;
	}

	public Area getCookingArea() {
		return COOKING_AREA;
	}

	public Tile getBankTile() {
		return BANK_TILE;
	}

	public Tile getCookingTile() {
		return COOKING_TILE;
	}

	public GameObject getGameObject() {
		final GameObject range = Objects.getNearest(objects);
		if (range != null) {
			return range;
		}
		return null;
	}
	
	public String getGameObjectName() {
		return "Range";
	}

	public int getCookTimeout() {
		return 500;
	}
	
	public boolean traverseBank() {
		final GameObject door = Objects.getNearest(DOOR);
		if (door != null && COOKING_AREA.contains(Players.getLocal().getLocation())) {
			if (Calculations.distanceTo(door.getLocation()) < 3 && door.isOnScreen()) {
				door.click();
				for (int i = 0; i < 10 && Objects.getNearest(DOOR) != null; i++) {
					Task.sleep(100, 200);
				}
			} else {
				new LocalPath(DOOR_TILE).traverse();
				// DOOR_TILE.clickOnMap();
			}
		} else {
			new LocalPath(BANK_TILE).traverse();
		}
		return true;
	}
	
	public boolean traverseCook() {
		final GameObject door = Objects.getNearest(DOOR);
		if (door != null && !COOKING_AREA.contains(Players.getLocal().getLocation())) {
			if (Calculations.distanceTo(door.getLocation()) < 3 && door.isOnScreen()) {
				door.click();
				for (int i = 0; i < 10 && Objects.getNearest(DOOR) != null; i++) {
					Task.sleep(100, 200);
				}
			} else {
				new LocalPath(DOOR_FRONT).traverse();
			}
		} else {
			new LocalPath(COOKING_TILE).traverse();
		}
		return true;
	}
}
