package noeffex.cooker.plugins.cookers;

import com.rsbuddy.script.methods.Objects;
import com.rsbuddy.script.methods.Players;
import com.rsbuddy.script.task.Task;
import com.rsbuddy.script.util.Random;
import com.rsbuddy.script.wrappers.Area;
import com.rsbuddy.script.wrappers.GameObject;
import com.rsbuddy.script.wrappers.LocalPath;
import com.rsbuddy.script.wrappers.Tile;
import noeffex.cooker.plugins.*;
import noeffex.cooker.utils.CookerUtils;

@CookerManifest(name="Edgeville")
public class Edgeville extends CookerPlugin {
	private static final int[] GATE = { 15514, 15516 };
	private static final Area GATE_AREA = new Area(3077, 3497, 3081, 3500);
	private static final Tile[] GATE_INSIDE = { new Tile(3080, 3500), new Tile(3079, 3500) };
	private static final Tile[] GATE_TILES = { new Tile(3080, 3501), new Tile(3079, 3501) };

	private static final int DOOR = 24381;
	private static final Tile DOOR_INSIDE = new Tile(3079, 3496);
	private static final Tile DOOR_FRONT = new Tile(3079, 3497);

	private static final int STOVE = 12269;

	private static final Area BANK_AREA = new Area(3091, 3488, 3098, 3499);
	private static final Tile BANK_TILE = new Tile(3094, 3493);
	private static final Area COOKING_AREA = new Area(3077, 3489, 3081, 3496);
	private static final Tile COOKING_TILE = new Tile(3079, 3495);

	public Area getBankArea() {
		return BANK_AREA;
	}

	public Tile getBankTile() {
		return BANK_TILE;
	}

	public Area getCookingArea() {
		return COOKING_AREA;
	}

	public Tile getCookingTile() {
		return COOKING_TILE;
	}

	public boolean traverseBank() {
		if (GATE_AREA.contains(Players.getLocal().getLocation())) {
			final GameObject GATE_OBJECT = Objects.getNearest(GATE);
			if (GATE_OBJECT != null && GATE_OBJECT.isOnScreen()) {
				GATE_OBJECT.click();
				for (int i = 0; i < 10 && Objects.getNearest(DOOR) != null; i++) {
					Task.sleep(100, 200);
				}
			} else if (GATE_OBJECT != null) {
				GATE_INSIDE[Random.nextInt(0, GATE_INSIDE.length)].clickOnMap();
				for (int i = 0; i < 10 && !GATE_OBJECT.isOnScreen(); i++) {
					Task.sleep(100, 200);
				}
			} else {
				new LocalPath(BANK_TILE).traverse();
			}
		} else {
			final GameObject DOOR_OBJECT = Objects.getNearest(DOOR);
			if (DOOR_OBJECT != null && DOOR_OBJECT.isOnScreen()) {
				DOOR_OBJECT.click();
				for (int i = 0; i < 10 && Objects.getNearest(DOOR) != null; i++) {
					Task.sleep(100, 200);
				}
			} else if (DOOR_OBJECT != null) {
				DOOR_INSIDE.clickOnMap();
				for (int i = 0; i < 10 && !DOOR_OBJECT.isOnScreen(); i++) {
					Task.sleep(100, 200);
				}
			} else {
				new LocalPath(BANK_TILE).traverse();
			}
		}
		return true;
	}

	public boolean traverseCook() {
		final GameObject GATE_OBJECT = Objects.getNearest(GATE);
		if (GATE_OBJECT != null && GATE_OBJECT.isOnScreen()) {
			if (GATE_OBJECT.click()) {
				for (int i = 0; i < 10 && Objects.getNearest(DOOR) != null; i++) {
					Task.sleep(100, 200);
				}
			}
		} else if (GATE_OBJECT != null) {
			LocalPath pathToGate = new LocalPath(GATE_TILES[Random.nextInt(0, GATE_TILES.length)]);
			if (pathToGate.traverse()) {
				for (int i = 0; i < 10 && !GATE_OBJECT.isOnScreen(); i++) {
					Task.sleep(100, 200);
				}
			}
		} else {
			final GameObject DOOR_OBJECT = Objects.getNearest(DOOR);
				if (DOOR_OBJECT != null && DOOR_OBJECT.isOnScreen()) {
				if (DOOR_OBJECT.click()) {
					for (int i = 0; i < 10 && Objects.getNearest(DOOR) != null; i++) {
						Task.sleep(100, 200);
					}
				}
			} else if (DOOR_OBJECT != null) {
			LocalPath pathToDoor = new LocalPath(DOOR_FRONT);
				if (pathToDoor.traverse()) {
					for (int i = 0; i < 10 && !DOOR_OBJECT.isOnScreen(); i++) {
						Task.sleep(100, 200);
					}
				}
			} else {
				new LocalPath(COOKING_TILE).traverse();
			}
		}
		return true;
	}

	public GameObject getGameObject() {
		final GameObject STOVE_OBJECT = Objects.getNearest(STOVE);
		return STOVE_OBJECT;
	}

	public String getGameObjectName() {
		return "Stove";
	}
}
