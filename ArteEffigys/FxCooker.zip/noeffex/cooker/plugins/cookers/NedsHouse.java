package noeffex.cooker.plugins.cookers;

import com.rsbuddy.script.methods.Calculations;
import com.rsbuddy.script.methods.Objects;
import com.rsbuddy.script.methods.Players;
import com.rsbuddy.script.task.Task;
import com.rsbuddy.script.util.Filter;
import com.rsbuddy.script.wrappers.Area;
import com.rsbuddy.script.wrappers.GameObject;
import com.rsbuddy.script.wrappers.LocalPath;
import com.rsbuddy.script.wrappers.Tile;
import noeffex.cooker.plugins.CookerManifest;
import noeffex.cooker.plugins.CookerPlugin;

@CookerManifest(name="Ned's House")
public class NedsHouse extends CookerPlugin {
	private static final Area BANK_AREA = new Area(3092, 3240, 3097, 3245);
	private static final Tile BANK_TILE = new Tile(3092, 3243);
	private static final Area COOK_AREA = new Area(3096, 3256, 3101, 3261);
	private static final Tile COOK_TILE = new Tile(3100, 3257);

	private static final Filter<GameObject> DOOR = new Filter<GameObject>() {
		public boolean accept(final GameObject object) {
			if (object == null) {
				return false;
			}
			if (object.getId() == DOOR_ID && object.getLocation().equals(DOOR_INSIDE)) {
				return true;
			}
			return false;
		}
	};

	private static final int DOOR_ID = 1530;
	private static final Tile DOOR_FRONT = new Tile(3102, 3258);
	private static final Tile DOOR_INSIDE = new Tile(3101, 3258);

	private static final int FIREPLACE = 2724;

	public Area getBankArea() {
		return BANK_AREA;
	}

	public Tile getBankTile() {
		return BANK_TILE;
	}

	public Area getCookingArea() {
		return COOK_AREA;
	}

	public Tile getCookingTile() {
		return COOK_TILE;
	}

	public boolean traverseBank() {
		final GameObject door = Objects.getNearest(DOOR);
		if (door != null && COOK_AREA.contains(Players.getLocal().getLocation()) && door.isOnScreen()) {
			if (door.click()) {
				for (int i = 0; i < 10 && Objects.getNearest(DOOR) != null; i++) {
					Task.sleep(100, 200);
				}
			}
		} else if (door != null && COOK_AREA.contains(Players.getLocal().getLocation())) {
			new LocalPath(DOOR_INSIDE).traverse();
		} else {
			new LocalPath(BANK_TILE).traverse();
		}
		return true;
	}

	public boolean traverseCook() {
		final GameObject door = Objects.getNearest(DOOR);
		if (door != null && !COOK_AREA.contains(Players.getLocal().getLocation()) && door.isOnScreen() && Calculations.distanceTo(door) < 3) {
			if (door.click()) {
				for (int i = 0; i < 10 && Objects.getNearest(DOOR) != null; i++) {
					Task.sleep(100, 200);
				}
			}
		} else if (door != null && !COOK_AREA.contains(Players.getLocal().getLocation())) {
			new LocalPath(DOOR_FRONT).traverse();
		} else {
			new LocalPath(COOK_TILE).traverse();
		}
		return true;
	}

	public GameObject getGameObject() {
		return Objects.getNearest(FIREPLACE);
	}

	public String getGameObjectName() {
		return "Fireplace";
	}
}
