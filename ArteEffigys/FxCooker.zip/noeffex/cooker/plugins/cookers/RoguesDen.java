package noeffex.cooker.plugins.cookers;

import com.rsbuddy.script.methods.Npcs;
import com.rsbuddy.script.methods.Objects;
import com.rsbuddy.script.wrappers.*;
import noeffex.cooker.plugins.CookerManifest;
import noeffex.cooker.plugins.CookerPlugin;

@CookerManifest(name="Rogue's Den")
public class RoguesDen extends CookerPlugin {
	private static final int BANKER = 2271;
	private static final int FIRE = 2732;
	private static final Area BANK_AREA = new Area(3039, 4964, 3061, 4983);
	private static final Tile BANK_TILE = new Tile(3042, 4971);
	private static final Area COOK_AREA = new Area(3041, 4971, 3045, 4975);
	private static final Tile COOK_TILE = new Tile(3043, 4972);

	public Area getBankArea() {
		return BANK_AREA;
	}

	public Tile getBankTile() {
		final Npc banker = Npcs.getNearest(BANKER);
		if (banker != null) {
			return banker.getLocation();
		}
		return BANK_TILE;
	}

	public Area getCookingArea() {
		return COOK_AREA;
	}

	public Tile getCookingTile() {
		return COOK_TILE;
	}

	public GameObject getGameObject() {
		final GameObject fireObject = Objects.getNearest(FIRE);
		return fireObject;
	}

	public String getGameObjectName() {
		return "Fire";
	}

	public int getCookTimeout() {
		return 200;
	}
}
