package noeffex.cooker.plugins.states;

import com.rsbuddy.script.task.Task;
import noeffex.cooker.utils.CookerUtils;
import noeffex.methods.Bank;

import com.rsbuddy.script.methods.*;

import noeffex.cooker.Static;
import noeffex.states.*;

@StatePlugin(name="Banking")
public class BankGroup extends StateGroup {
	// private static final Class<?>[] children = { DropAll.class, BankAreaGroup.class, WalkBank.class };
	private static final StateNode[] children = { new BankAreaGroup(), new WalkBank() };
	
	public boolean activateGroup() {
		return (!Bank.DepositBox.isOpen() && !Inventory.containsOneOf(Static.FOOD)) || Bank.DepositBox.getCount() == 28;
	}
	
	public StateNode[] getChildren() {
		return children;
	}
	
	@StatePlugin(name="Bank Area")
	public static class BankAreaGroup extends StateGroup {
		// private Class<?>[] children = { DepositBank.class, OpenBank.class };
		private static final StateNode[] children = { new WithdrawBank(), new DepositBank(), new OpenBank() };
		
		public boolean activateGroup() {
			return Static.cooker.getBankArea().contains(Players.getLocal().getLocation());
		}
		
		public StateNode[] getChildren() {
			return children;
		}

		@StatePlugin(name="Depositing Items")
		public static class DepositBank extends StateNode {
			public boolean activate() {
				return Bank.isOpen() || Bank.DepositBox.isOpen();
			}
			
			public void execute() {
				if (Bank.DepositBox.isOpen()) {
					Bank.DepositBox.depositAll();
				} else if (Bank.isOpen()) {
					Bank.depositAll();
					for (int i = 0; i < 10 && Inventory.isFull(); i++) {
						Task.sleep(100, 200);
					}
				}
			}
			
			public boolean isConcurrent() {
				return false;
			}
		}
		
		@StatePlugin(name="Withdrawing Items")
		public static class WithdrawBank extends StateNode {
			public boolean activate() {
				return (Bank.isOpen() || Bank.DepositBox.isOpen()) && !Inventory.isFull();
			}
			
			public void execute() {
				if (Bank.getCount(Static.FOOD) <= 0) {
					for (int i = 0; i < 10 && Bank.getCount(Static.FOOD) <= 0; i++) {
						Task.sleep(100, 200);
					}
					if (Bank.getCount(Static.FOOD) <= 0) {
						CookerUtils.log("Stopping script because we're out of food");
						Static.SCRIPT_STOP = true;
						return;
					}
				}
				Bank.withdraw(Static.FOOD[0], 0);
			}
			
			public boolean isConcurrent() {
				return false;
			}
		}
	
		@StatePlugin(name="Opening Bank")
		public static class OpenBank extends StateNode {
			public boolean activate() {
				return true;
			}
	
			public void execute() {
				if (Static.cooker.isDepositBox()) {
					if (!Bank.DepositBox.open()) {
						return;
					}
				} else {
					if (!Bank.open()) {
						return;
					}
				}
				for (int i = 0; i < 20 && !Bank.isOpen() && !Bank.DepositBox.isOpen(); i++) {
					sleep(100, 200);
				}
			}
			
			public boolean isConcurrent() {
				return false;
			}
		}
	}

	@StatePlugin(name="Walking to Bank")
	public static class WalkBank extends StateNode {
		public boolean activate() {
			return true;
		}
		
		public void execute() {
			Static.cooker.traverseBank();
		}
		
		public boolean isConcurrent() {
			return false;
		}
	}
}
