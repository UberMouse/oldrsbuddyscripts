package noeffex.cooker.plugins.states;

import com.rsbuddy.script.task.Task;

import noeffex.methods.Bank;
import noeffex.states.StateGroup;
import noeffex.states.StateNode;
import noeffex.states.StatePlugin;

@StatePlugin(name="Closing Bank")
public class CloseBankGroup extends StateGroup {
	private static final StateNode[] children = { new CloseRegular(), new CloseBox() };
	
	public boolean activateGroup() {
		return Bank.isOpen() || Bank.DepositBox.isOpen();
	}
	
	public StateNode[] getChildren() {
		return children;
	}
	
	public static class CloseRegular extends StateNode {
		public boolean activate() {
			return Bank.isOpen();
		}
		
		public void execute() {
			Bank.close();
		}
	}
	
	public static class CloseBox extends StateNode {
		public boolean activate() {
			return Bank.DepositBox.isOpen();
		}
		
		public void execute() {
			Bank.DepositBox.close();
			for (int i = 0; i < 20 && Bank.DepositBox.isOpen(); i++) {
				Task.sleep(100, 200);
			}
		}
	}
}
