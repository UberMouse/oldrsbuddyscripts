package noeffex.cooker.plugins.states;

import com.rsbuddy.script.methods.Inventory;
import com.rsbuddy.script.methods.Players;
import com.rsbuddy.script.methods.Widgets;
import com.rsbuddy.script.task.Task;
import com.rsbuddy.script.wrappers.Component;
import com.rsbuddy.script.wrappers.GameObject;
import com.rsbuddy.script.wrappers.Item;
import com.rsbuddy.script.wrappers.Widget;

import noeffex.cooker.Static;
import noeffex.cooker.utils.CookerUtils;
import noeffex.states.StateGroup;
import noeffex.states.StateNode;
import noeffex.states.StatePlugin;

@StatePlugin(name="Cooking")
public class CookingGroup extends StateGroup {
	private final StateNode[] children = { new CookIdle(), new NavigateIfaceNode(), new CookNode(), new TraverseNode() };
	
	private static final int COOK_INTERFACE_MAIN = 905;
	private static final int COOK_INTERFACE_BUTTON = 14;
	
	public StateNode[] getChildren() {
		return children;
	}
	
	public boolean activateGroup() {
		return true;
	}
	
	class CookIdle extends StateNode {
		public boolean activate() {
			return Static.utilThread.getIdle() < Static.cooker.getCookTimeout() && Inventory.containsAll(Static.FOOD);
		}
		
		public void execute() {
			Task.sleep(100);
		}
	}
	
	@StatePlugin(name="Navigating Interface")
	class NavigateIfaceNode extends StateNode {
		public boolean activate() {
			Widget cookMain = Widgets.get(COOK_INTERFACE_MAIN);
			if (cookMain != null) {
				Component button = cookMain.getComponent(COOK_INTERFACE_BUTTON);
				if (button != null && button.isVisible() && button.isValid()) {
					return true;
				}
			}
			return false;
		}
		
		public void execute() {
			Widget cookMain = Widgets.get(COOK_INTERFACE_MAIN);
			if (cookMain != null) {
				Component button = cookMain.getComponent(COOK_INTERFACE_BUTTON);
				if (button.click()) {
                    for (int i = 0; i < 10 && Static.utilThread.getIdle() > 0; i++) {
                        Task.sleep(100, 200);
                    }
                }
			}
		}
	}

	@StatePlugin(name="Applying food to cooker")
	class CookNode extends StateNode {
		public boolean activate() {
			return Static.cooker.getCookingArea().contains(Players.getLocal().getLocation());
		}
		
		public void execute() {
			final GameObject object = Static.cooker.getGameObject();
			if (object != null) {
				final Item food = Inventory.getItem(Static.FOOD);
				if (food != null) {
					if (!Inventory.isItemSelected()) {
						if (food.interact("Use")) {
							for (int i = 0; i < 10 && !Inventory.isItemSelected(); i++) {
								Task.sleep(100, 200);
							}
						}
					} else {
						if (object.interact("Use " + food.getName().replace("<col=ff9040>", "") + " -> " + Static.cooker.getGameObjectName())) {
							for (int i = 0; i < 20 && !Widgets.getComponent(COOK_INTERFACE_MAIN, COOK_INTERFACE_BUTTON).isVisible(); i++) {
								Task.sleep(100, 200);
							}
						}
					}
				} else {
					CookerUtils.log("food was null");
				}
			} else {
				CookerUtils.log("object was null");
			}
		}
		
		public boolean isConcurrent() {
			return false;
		}
	}
	
	@StatePlugin(name="Walking to cooking area")
	class TraverseNode extends StateNode {
		public boolean activate() {
			return !Static.cooker.getCookingArea().contains(Players.getLocal().getLocation());
		}
		
		public void execute() {
			Static.cooker.traverseCook();
		}
	}
}
