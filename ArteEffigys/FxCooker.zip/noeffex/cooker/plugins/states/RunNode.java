package noeffex.cooker.plugins.states;


import com.rsbuddy.script.methods.Game;
import com.rsbuddy.script.methods.Walking;
import com.rsbuddy.script.task.Task;
import noeffex.cooker.Static;
import noeffex.states.StateNode;
import noeffex.states.StatePlugin;

@StatePlugin(name="Enabling Run")
public class RunNode extends StateNode {
	public boolean activate() {
		return Game.isLoggedIn() &&  !Walking.isRunEnabled() && Walking.getEnergy() > Static.gui.getRunEnergy();
	}

	public void execute() {
		Walking.setRun(true);
		for (int i = 0; i < 10 && !Walking.isRunEnabled(); i++) {
			Task.sleep(100, 200);
		}
	}
}
