package noeffex.cooker.utils;

import noeffex.cooker.FxCooker;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.util.zip.GZIPInputStream;

public class CookerUtils {
	public static void log(final Object message) {
		FxCooker.reference.log(message);
	}

	public static double distanceBetween(final Point left, final Point right) {
		return Math.sqrt(Math.pow(right.x - left.x, 2) + Math.pow(right.y - left.y, 2));
	}

	public static BufferedImage getImage(final byte[] gzip) {
		// uncompress gz
		try {
			final ByteArrayInputStream byteInput = new ByteArrayInputStream(gzip);
			final GZIPInputStream input = new GZIPInputStream(byteInput);
			return ImageIO.read(input);
		} catch (final Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}
