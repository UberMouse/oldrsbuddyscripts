package noeffex.methods;

import java.awt.Point;
import java.awt.Rectangle;
import java.util.LinkedList;

import com.rsbuddy.script.methods.Calculations;
import com.rsbuddy.script.methods.Camera;
import com.rsbuddy.script.methods.Game;
import com.rsbuddy.script.methods.Inventory;
import com.rsbuddy.script.methods.Keyboard;
import com.rsbuddy.script.methods.Menu;
import com.rsbuddy.script.methods.Mouse;
import com.rsbuddy.script.methods.Npcs;
import com.rsbuddy.script.methods.Objects;
import com.rsbuddy.script.methods.Players;
import com.rsbuddy.script.methods.Settings;
import com.rsbuddy.script.methods.Walking;
import com.rsbuddy.script.methods.Widgets;
import com.rsbuddy.script.task.Task;
import com.rsbuddy.script.util.Random;
import com.rsbuddy.script.util.Timer;
import com.rsbuddy.script.wrappers.Component;
import com.rsbuddy.script.wrappers.GameObject;
import com.rsbuddy.script.wrappers.Item;
import com.rsbuddy.script.wrappers.Npc;
import com.rsbuddy.script.wrappers.Widget;

/**
 * Bank related operations.
 */
public class Bank {

	public static final int[] BANKERS = {44, 45, 494, 495, 498, 499, 909, 958, 1036, 2271, 2354, 2355, 3824, 5488, 5901, 5912, 5913, 6362, 6532, 6533, 6534, 6535, 7605, 8948, 9710, 14367};
	public static final int[] BANK_BOOTHS = {2213, 4483, 6084, 10517, 11402, 11758, 12759, 14367, 19230, 24914, 25808, 26972, 27663, 29085, 52589, 34752, 35647};
	public static final int[] BANK_CHESTS = {4483, 12308, 21301, 27663, 42192};

	public static final int[] DO_NOT_DEPOSIT = new int[]{1265, 1267, 1269, 1273, 1271, 1275, 1351, 590, 303};

	public static final int WIDGET = 762;
	public static final int BUTTON_CLOSE = 43;
	public static final int BUTTON_DEPOSIT_BEAST = 38;
	public static final int BUTTON_DEPOSIT_CARRIED = 34;
	public static final int BUTTON_DEPOSIT_WORN = 36;
	public static final int BUTTON_HELP = 44;
	public static final int BUTTON_INSERT = 15;
	public static final int BUTTON_ITEM = 19;
	public static final int BUTTON_NOTE = 19;
	public static final int BUTTON_SEARCH = 17;
	public static final int BUTTON_SWAP = 15;
	public static final int BUTTON_EQUIPMENT = 117;
	public static final int COMPONENT_INVENTORY = 93;
	public static final int COMPONENT_F2P_ITEM_COUNT = 29;
	public static final int COMPONENT_F2P_ITEM_MAX = 30;
	public static final int COMPONENT_P2P_ITEM_COUNT = 31;
	public static final int COMPONENT_P2P_ITEM_MAX = 32;
	public static final int COMPONENT_SCROLL_BAR = 114;
	public static final int COMPONENT_SEARCH = 752;
	public static final int COMPONENT_SEARCH_INPUT = 5;

	public static final int WIDGET_EQUIP = 667;
	public static final int COMPONENT_EQUIP_INVENTORY = 7;

	public static final int WIDGET_COLLECTION_BOX = 105;
	public static final int BUTTON_COLLECTION_BOX_CLOSE = 13;

	public static final int[] COMPONENT_BANK_TABS = {63, 61, 59, 57, 55, 53, 51, 49, 47};
	public static final int[] COMPONENT_BANK_FIRST_ITEMS = {78, 79, 80, 81, 82, 83, 84, 85, 86};

	/**
	 * Closes the bank interface. Supports deposit boxes.
	 *
	 * @return <tt>true</tt> if the bank interface is no longer open.
	 */
	public static boolean close() {
		if (isOpen()) {
			Widgets.getComponent(WIDGET, BUTTON_CLOSE).click();
			Task.sleep(Random.nextInt(500, 600));
			return !isOpen();
		}
		if (DepositBox.isOpen()) {
			return DepositBox.close();
		}
		return DepositBox.isOpen() && DepositBox.close();
	}

	/**
	 * If bank is open, deposits specified amount of an item into the bank.
	 *
	 * @param itemID The ID of the item.
	 * @param number The amount to deposit. 0 deposits All. 1,5,10 deposit
	 *               corresponding amount while other numbers deposit X.
	 * @return <tt>true</tt> if successful; otherwise <tt>false</tt>.
	 */
	public static boolean deposit(int itemID, int number) {
		if (isOpen()) {
			if (number < 0) {
				throw new IllegalArgumentException("number < 0 (" + number + ")");
			}
			int invCount = Inventory.getCount(true);
			if (Inventory.getItem(itemID) == null)
				return false;
			Component item = Inventory.getItem(itemID).getComponent();
			int itemCount = Inventory.getCount(true, itemID);
			if (item == null) {
				return true;
			}

			if (number == Inventory.getCount(true, itemID))
				number = 0;

			switch (number) {
				case 0: // Deposit All
					if (item.interact(itemCount > 1 ? "Deposit-All" : "Deposit"))
						break;
					else return false;
				case 1:
					if (item.interact("Deposit"))
						break;
					else return false;
				case 5:
					if (item.interact("Deposit-" + number))
						break;
					else return false;
				default: // Deposit x
					if (!item.interact("Deposit-" + number)) {
						if (item.interact("Deposit-X")) {
							Task.sleep(Random.nextInt(1000, 1300));
							// Context.current().getInputHandler().sendKeys(String.valueOf(number), true);
							Keyboard.sendText(String.valueOf(number), true);
						} else
							return false;

					}
					break;
			}
			for (int i = 0; i < 1500; i += 20) {
				Task.sleep(20);
				int cInvCount = Inventory.getCount(true);
				if (cInvCount < invCount || cInvCount == 0)
					return true;
			}
		}
		return false;
	}

	/**
	 * Deposits all items in Inventory.
	 *
	 * @return <tt>true</tt> on success.
	 */
	public static boolean depositAll() {
		return isOpen() && Widgets.getComponent(WIDGET, BUTTON_DEPOSIT_CARRIED).click();
	}

	/**
	 * Deposits all items in inventory except for the given IDs.
	 *
	 * @param items The items not to deposit.
	 * @return true on success.
	 */
	public static boolean depositAllExcept(int... items) {
		if (isOpen()) {
			if (!Inventory.containsOneOf(items))
				return depositAll();
			boolean deposit = true;
			int invCount = Inventory.getCount(true);
			outer:
			for (int i = 0; i < 28; i++) {
				Component item = Inventory.getItemAt(i).getComponent();
				if (item != null && item.getItemId() != -1) {
					for (int id : items) {
						if (item.getItemId() == id) {
							continue outer;
						}
					}
					for (int tries = 0; tries < 5; tries++) {
						deposit(item.getItemId(), 0);
						Task.sleep(Random.nextInt(600, 900));
						int cInvCount = Inventory.getCount(true);
						if (cInvCount < invCount) {
							invCount = cInvCount;
							continue outer;
						}
					}
					deposit = false;
				}
			}
			return deposit;
		}
		return false;
	}

	/**
	 * Deposit everything your player has equipped.
	 *
	 * @return <tt>true</tt> on success.
	 * @since 6 March 2009.
	 */
	public static boolean depositAllEquipped() {
		return isOpen() && Widgets.getComponent(WIDGET, BUTTON_DEPOSIT_WORN).click();
	}

	/**
	 * Deposits everything your familiar is carrying.
	 *
	 * @return <tt>true</tt> on success
	 * @since 6 March 2009.
	 */
	public static boolean depositAllFamiliar() {
		return isOpen() && Widgets.getComponent(WIDGET, BUTTON_DEPOSIT_BEAST).click();
	}

	/**
	 * Returns the sum of the count of the given items in the bank.
	 *
	 * @param items The array of items.
	 * @return The sum of the stacks of the items.
	 */
	public static int getCount(final int... items) {
		if (!isOpen())
			return 0;
		int itemCount = 0;
		final Item[] inventoryArray = getItems();
		for (Item item : inventoryArray) {
			for (final int id : items) {
				if (item.getId() == id) {
					itemCount += item.getStackSize();
				}
			}
		}
		return itemCount;
	}

	/**
	 * Get current tab open in the bank.
	 *
	 * @return int of tab (0-8), or -1 if none are selected (bank is not open).
	 */
	public static int getCurrentTab() {
		for (int i = 0; i < COMPONENT_BANK_TABS.length; i++) {
			if (getWidget().getComponent(
					COMPONENT_BANK_TABS[i] - 1).getTextureId() == 1419)
				return i;
		}
		return -1; // no selected ones. bank may not be open.
	}

	/**
	 * Gets the bank interface.
	 *
	 * @return The bank <code>Widget</code>.
	 */
	public static Widget getWidget() {
		return Widgets.get(WIDGET);
	}

	/**
	 * Gets the deposit box interface.
	 *
	 * @return The deposit box <code>Widget</code>.
	 * @deprecated Use Bank.DepositBox.getWidget() instead.
	 */
	@Deprecated
	public static Widget getDepositBoxWidget() {
		return Widgets.get(DepositBox.WIDGET_DEPOSIT_BOX);
	}

	/**
	 * Gets the <code>Component</code> of the given item at the specified
	 * index.
	 *
	 * @param index The index of the item.
	 * @return <code>Component</code> if item is found at index; otherwise
	 *         null.
	 */
	public static Item getItemAt(final int index) {
		final Item[] items = getItems();
		if (items != null) {
			for (final Item item : items) {
				if (item.getComponent().getChildIndex() == index)
					return item;
			}
		}

		return null;
	}

	/**
	 * Gets the first item with the provided ID in the bank.
	 *
	 * @param id ID of the item to get.
	 * @return The component of the item; otherwise null.
	 */
	public static Item getItem(final int id) {
		if (isOpen()) {
			final Item[] items = getItems();
			if (items != null) {
				for (final Item item : items) {
					if (item.getId() == id)
						return item;
				}
			}
		}
		return null;
	}

	/**
	 * Gets all the items in the bank's Inventory.
	 *
	 * @return an <code>Item</code> array of the bank's inventory interface.
	 */
	public static Item[] getItems() {
		if (!isOpen()
				|| getWidget() == null
				|| getWidget().getComponent(COMPONENT_INVENTORY) == null)
			return new Item[0];

		Component[] components = getWidget().getComponent(COMPONENT_INVENTORY).getComponents();
		Item[] items = new Item[components.length];
		for (int i = 0; i < items.length; ++i) {
			items[i] = new Item(components[i]);
		}
		return items;
	}

	/**
	 * Checks whether or not the bank is open.
	 *
	 * @return <tt>true</tt> if the bank interface is open; otherwise
	 *         <tt>false</tt>.
	 */
	public static boolean isOpen() {
		return getWidget().isValid();
	}

	/**
	 * Checks whether or not the deposit box is open.
	 *
	 * @return <tt>true</tt> if the deposit box interface is open; otherwise
	 *         <tt>false</tt>.
	 * @deprecated Use Bank.DepositBox.isOpen() instead.
	 */
	@Deprecated
	public static boolean isDepositBoxOpen() {
		return DepositBox.isOpen();
	}

	/**
	 * Opens one of the supported banker NPCs, booths, or chests nearby. If they
	 * are not nearby, and they are not null, it will automatically walk to the
	 * closest one.
	 *
	 * @return <tt>true</tt> if the bank was opened; otherwise <tt>false</tt>.
	 */
	public static boolean open() {
		try {
			if (!isOpen()) {
				if (Menu.isOpen()) {
					Mouse.moveSlightly();
					Task.sleep(Random.nextInt(20, 30));
				}
				GameObject bankBooth = Objects.getNearest(BANK_BOOTHS);
				Npc banker = Npcs.getNearest(BANKERS);
				final GameObject bankChest = Objects.getNearest(BANK_CHESTS);
				int lowestDist = Calculations.distanceTo(bankBooth);
				if ((banker != null)
						&& (Calculations.distanceTo(banker) < lowestDist)) {
					lowestDist = Calculations.distanceTo(banker);
					bankBooth = null;
				}
				if ((bankChest != null)
						&& (Calculations.distanceTo(bankChest) < lowestDist)) {
					bankBooth = null;
					banker = null;
				}
				if (((bankBooth != null)
						&& (Calculations.distanceTo(bankBooth) < 5)
						&& Calculations.isTileOnMap(bankBooth.getLocation())) || ((banker != null)
						&& (Calculations.distanceTo(banker) < 8)
						&& Calculations.isTileOnMap(banker.getLocation())) || ((bankChest != null)
						&& (Calculations.distanceTo(bankChest) < 8)
						&& Calculations.isTileOnMap(bankChest.getLocation()) && !isOpen())) {
					if (bankBooth != null) {
						if (bankBooth.interact("Use-Quickly")) {
							int count = 0;
							while (!isOpen() && ++count < 10) {
								Task.sleep(Random.nextInt(200, 400));
								if (Players.getLocal().isMoving()) {
									count = 0;
								}
							}
						} else {
							Camera.turnTo(bankBooth);
						}
					} else if (banker != null) {
						if (banker.interact("Bank ")) {
							int count = 0;
							while (!isOpen() && ++count < 10) {
								Task.sleep(Random.nextInt(200, 400));
								if (Players.getLocal().isMoving()) {
									count = 0;
								}
							}
						} else {
							Camera.turnTo(banker, 20);
						}
					} else if (bankChest != null) {
						if (bankChest.interact("Bank")
								|| Menu.click("Use")) {
							int count = 0;
							while (!isOpen() && ++count < 10) {
								Task.sleep(Random.nextInt(200, 400));
								if (Players.getLocal().isMoving()) {
									count = 0;
								}
							}
						} else {
							Camera.turnTo(bankChest);
						}
					}
				} else {
					if (bankBooth != null) {
						Walking.stepTowards(bankBooth.getLocation());
					} else if (banker != null) {
						Walking.stepTowards(banker.getLocation());
					} else if (bankChest != null) {
						Walking.stepTowards(bankChest.getLocation());
					}
				}
			}
			return isOpen();
		} catch (final Exception e) {
			e.printStackTrace();
			return false;
		}
	}

	/**
	 * Opens one of the supported deposit boxes nearby. If they are not nearby,
	 * and they are not null, it will automatically walk to the closest one.
	 *
	 * @return <tt>true</tt> if the deposit box was opened; otherwise <tt>false</tt>.
	 * @deprecated @deprecated Use Bank.DepositBox.open() instead.
	 */
	@Deprecated
	public static boolean openDepositBox() {
		return DepositBox.open();
	}

	/**
	 * @return <tt>true</tt> if currently searching the bank.
	 */
	public static boolean isSearchOpen() {
		// Setting 1248 is -2147483648 when search is enabled and -2013265920
		return (Settings.get(1248) == 0x80000000);
	}

	/**
	 * Searches for an item in the bank. Returns true if succeeded (does not
	 * necessarily mean it was found).
	 *
	 * @param itemName The item getName to find.
	 * @return <tt>true</tt> on success.
	 */
	public static boolean search(final String itemName) {
		if (!isOpen())
			return false;
		Widgets.getComponent(WIDGET, BUTTON_SEARCH).interact("Search");
		Task.sleep(Random.nextInt(1000, 1500));
		if (!isSearchOpen()) {
			Task.sleep(500);
		}
		if (isOpen() && isSearchOpen()) {
			// Context.current().getInputHandler().sendKeys(itemName, false);
			Keyboard.sendText(itemName, true);
			Task.sleep(Random.nextInt(300, 700));
			return true;
		}
		return false;
	}

	/**
	 * Sets the bank rearrange mode to insert.
	 *
	 * @return <tt>true</tt> on success.
	 */
	public static boolean setRearrangeModeToInsert() {
		if (!isOpen())
			return false;
		if (Settings.get(Settings.SETTING_BANK_REARRANGE_MODE) != 1) {
			Widgets.getComponent(WIDGET,
					BUTTON_INSERT).click();
			Task.sleep(Random.nextInt(500, 700));
		}
		return Settings.get(Settings.SETTING_BANK_REARRANGE_MODE) == 1;
	}

	/**
	 * Sets the bank rearrange mode to swap.
	 *
	 * @return <tt>true</tt> on success.
	 */
	public static boolean setRearrangeModeToSwap() {
		if (!isOpen())
			return false;
		if (Settings.get(Settings.SETTING_BANK_REARRANGE_MODE) != 0) {
			Widgets.getComponent(WIDGET,
					BUTTON_SWAP).click();
			Task.sleep(Random.nextInt(500, 700));
		}
		return Settings.get(Settings.SETTING_BANK_REARRANGE_MODE) == 0;
	}

	/**
	 * Sets the bank withdraw mode to item.
	 *
	 * @return <tt>true</tt> on success.
	 */
	public static boolean setWithdrawModeToItem() {
		if (!isOpen())
			return false;
		if (Settings.get(Settings.SETTING_BANK_WITHDRAW_MODE) != 0) {
			Widgets.getComponent(WIDGET,
					BUTTON_ITEM).click();
			Task.sleep(Random.nextInt(500, 700));
		}
		return Settings.get(Settings.SETTING_BANK_WITHDRAW_MODE) == 0;
	}

	/**
	 * Sets the bank withdraw mode to note.
	 *
	 * @return <tt>true</tt> on success.
	 */
	public static boolean setWithdrawModeToNote() {
		if (!isOpen())
			return false;
		if (Settings.get(Settings.SETTING_BANK_WITHDRAW_MODE) != 1) {
			Widgets.getComponent(WIDGET,
					BUTTON_NOTE).click();
			Task.sleep(Random.nextInt(500, 700));
		}
		return Settings.get(Settings.SETTING_BANK_WITHDRAW_MODE) == 1;
	}

	/**
	 * Tries to withdraw an item. 0 is All. 1,5,10 use Withdraw 1,5,10 while other numbers Withdraw X.
	 *
	 * @param itemId The ID of the item.
	 * @param count  The number to withdraw.
	 * @return <tt>true</tt> on success.
	 */
	public static boolean withdraw(final int itemId, final int count) {
		if (isOpen()) {
			if (count < 0)
				throw new IllegalArgumentException("count (" + count + ") < 0");
			Item rsi = getItem(itemId);
			if (rsi == null)
				return false;
			Component item = rsi.getComponent();
			if (item == null)
				return false;

			if (item.getRelLocation().equals(new Point(0, 0))) {
				getWidget().getComponent(Bank.COMPONENT_BANK_TABS[0]).click();
				Task.sleep(1000, 1300);
			}

			Component container = getWidget().getComponent(93);
			if (!container.getViewportRect().contains(item.getBoundingRect())) {
				Point p = container.getAbsLocation();
				Rectangle r = container.getViewportRect();
				Mouse.move(
						Random.nextGaussian(p.x, p.y + r.width, r.width / 2),
						Random.nextGaussian(p.y, p.y + r.height, r.height / 2)
				);
				Timer limit = new Timer(5000);
				while (!container.getViewportRect().contains(item.getBoundingRect()) && limit.isRunning()) {
					Mouse.scroll(item.getAbsLocation().y < container.getAbsLocation().y);
					Task.sleep(20, 150);
				}
			}

			if (!container.getBoundingRect().contains(item.getBoundingRect()))
				return false;

			int invCount = Inventory.getCount(true);
			switch (count) {
				case 0:
					item.interact("Withdraw-All");
					break;
				case 1:
					item.click(true);
					break;
				case 5:
				case 10:
					item.interact("Withdraw-" + count);
					break;
				default:
					if (!item.interact("Withdraw-" + count)) {
						if (item.interact("Withdraw-X")) {
							Task.sleep(Random.nextInt(1000, 1300));
							Keyboard.sendText(String.valueOf(count), true);
						}
					}
			}
			for (int i = 0; i < 1500; i += 20) {
				Task.sleep(20);
				int newInvCount = Inventory.getCount(true);
				if (newInvCount > invCount || Inventory.isFull())
					return true;
			}
		}
		return false;
	}

	/**
	 * Gets the count of all the items in the inventory with the any of the
	 * specified IDs while deposit box is open.
	 *
	 * @param ids the item IDs to include
	 * @return The count.
	 * @deprecated Use Bank.DepositBox.getCount(boolean, int...) instead.
	 */
	@Deprecated
	public static int getDepositBoxCount(int... ids) {
		return DepositBox.getCount(false, ids);
	}

	/**
	 * Gets the count of all items in your inventory ignoring stack sizes while
	 * deposit box is open.
	 *
	 * @return The count.
	 * @deprecated Use Bank.DepositBox.getCount() instead.
	 */
	@Deprecated
	public static int getDepositBoxCount() {
		return DepositBox.getCount(false);
	}

	/**
	 * Gets the Equipment items from the bank interface.
	 *
	 * @return All Equipment items that are being worn.
	 */
	public static Item[] getEquipped() {
		if (Widgets.get(WIDGET_EQUIP).getComponent(
				COMPONENT_EQUIP_INVENTORY).isValid())
			return new Item[0];

		Component[] components = Widgets.get(WIDGET_EQUIP)
				.getComponent(COMPONENT_EQUIP_INVENTORY).getComponents();
		Item[] items = new Item[components.length];
		for (int i = 0; i < items.length; i++)
			items[i] = new Item(components[i]);

		return items;
	}

	/**
	 * Gets an Equipment item from the bank interface.
	 *
	 * @param id The item id.
	 * @return RSItem
	 */
	public static Item getEquipped(final int id) {
		Item[] items = getEquipped();
		if (items != null) {
			for (final Item item : items) {
				if (item.getId() == id)
					return item;
			}
		}
		return null;
	}

	/**
	 * Opens the Equipment interface.
	 *
	 * @return <tt>true</tt> if opened.
	 */
	public static boolean openEquipment() {
		return getWidget().getComponent(BUTTON_EQUIPMENT).isValid() &&
				getWidget().getComponent(BUTTON_EQUIPMENT).click();
	}

	/**
	 * Deposit Box related operations.
	 */
	public static class DepositBox {
		
		public static final int[] DEPOSIT_BOXES = { 9398, 20228, 26969, 36788, 45079, 32931, 32924, 32930 };

		public static final int WIDGET_DEPOSIT_BOX = 11;
		public static final int BUTTON_DEPOSIT_BOX_CLOSE = 15;
		public static final int WIDGET_INVENTORY = 17;
		public static final int BUTTON_DEPOSIT_BOX_DEPOSIT_BEAST = 23;
		public static final int BUTTON_DEPOSIT_BOX_DEPOSIT_CARRIED = 19;
		public static final int BUTTON_DEPOSIT_BOX_DEPOSIT_WORN = 21;

		/**
		 * Gets the deposit box widget.
		 *
		 * @return The deposit box <code>Widget</code>.
		 */
		public static Widget getWidget() {
			return Widgets.get(WIDGET_DEPOSIT_BOX);
		}

		/**
		 * If deposit box is open, deposits specified amount of an item.
		 *
		 * @param itemID The ID of the item.
		 * @param number The amount to deposit. 0 deposits All. 1,5,10 deposit
		 *               corresponding amount while other numbers deposit X.
		 * @return <tt>true</tt> if successful; otherwise <tt>false</tt>.
		 */
		public static boolean deposit(int itemID, int number) {
			if (isOpen()) {
				if (number < 0) {
					throw new IllegalArgumentException("number < 0 (" + number + ")");
				}
				int invCount = getCount(true);
				Item item = getItem(itemID);
				if (item == null)
					return false;
				int itemCount = getCount(true, itemID);

				if (number == getCount(true, itemID))
					number = 0;

				switch (number) {
					case 0: // Deposit All
						if (item.interact(itemCount > 1 ? "Deposit-All" : "Deposit"))
							break;
						else return false;
					case 1:
						if (item.interact("Deposit"))
							break;
						else return false;
					case 5:
						if (item.interact("Deposit-" + number))
							break;
						else return false;
					default: // Deposit x
						if (!item.interact("Deposit-" + number)) {
							if (item.interact("Deposit-X")) {
								Task.sleep(Random.nextInt(1000, 1300));
								// Context.current().getInputHandler().sendKeys(String.valueOf(number), true);
								Keyboard.sendText(String.valueOf(number), true);
							} else
								return false;

						}
						break;
				}
				for (int i = 0; i < 1500; i += 20) {
					Task.sleep(20);
					int cInvCount = getCount(true);
					if (cInvCount < invCount || cInvCount == 0)
						return true;
				}
			}
			return false;
		}

		/**
		 * Deposits all items in except for the given IDs.
		 *
		 * @param ids The items not to deposit.
		 * @return true on success.
		 */
		public static boolean depositAllExcept(int... ids) {
			if (!isOpen())
				return false;
			if (!containsOneOf(ids))
				return depositAll();
			// outer:
			for (int i = 0; i < 4; i++) {
				Item[] inventory = getItems();
				for (Item item : inventory) {
					boolean skip = false;
					for (int id : ids) {
						if (item.getId() == id) {
							skip = true;
							break;
						}
					}
					int itemId = item.getId();
					if (!skip && itemId != -1) {
						deposit(item.getId(), 0);
					}
				}
			}
			return true;
		}

		/**
		 * Returns the sum of the count of the given items in the bank.
		 *
		 * @param includeStacks - <tt>true</tt> to count the stack sizes of each item; <tt>false</tt> to count a stack as a single item.
		 * @param ids		   The array of items.
		 * @return The sum of the stacks of the items.
		 */
		public static int getCount(boolean includeStacks, int... ids) {
			if (!isOpen())
				return -1;

			int count = 0;
			Item[] inventory = getItems();
			for (Item item : inventory) {
				for (int i : ids) {
					if (item.getId() == i) {
						count += includeStacks ? item.getStackSize() : 1;
					}
				}
			}
			return count;
		}
		
		/**
		 * Returns the sum of the count of the given items in the bank, excluding stacks
		 *
		 * @return The number of items in the inventory
		 */
		public static int getCount() {
			return getCount(false);
		}

		/**
		 * Returns the sum of the count of the given items in the bank.
		 *
		 * @param includeStacks - <tt>true</tt> to count the stack sizes of each item; <tt>false</tt> to count a stack as a single item.
		 * @return The sum of the stacks of the items.
		 */
		public static int getCount(boolean includeStacks) {
			if (!isOpen()) {
				return -1;
			}
			int count = 0;
			for (Item item : getItems()) {
				if (item.getId() != -1) {
					count += includeStacks ? item.getStackSize() : 1;
				}
			}

			return count;
		}

		/**
		 * Gets all the items in the deposit box.
		 *
		 * @return an <code>Item</code> array of the deposit box's contents.
		 */
		public static Item[] getItems() {
			if (!isOpen())
				return new Item[0];

			LinkedList<Item> out = new LinkedList<Item>();
			try {
				for (Component c : getWidget().getComponent(WIDGET_INVENTORY).getComponents()) {
					if (c != null && c.isValid()) {
						out.add(new Item(c));
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			return out.toArray(new Item[out.size()]);
		}

		/**
		 * Gets the first item in the deposit box with any of the provided IDs.
		 *
		 * @param ids The IDs of the item to find.
		 * @return The first <tt>Item</tt> for the given IDs; otherwise <tt>null</tt>.
		 */
		public static Item getItem(int... ids) {
			if (isOpen()) {
				for (Item item : getItems()) {
					for (int id : ids) {
						if (item.getId() == id) {
							return item;
						}
					}
				}
			}
			return null;
		}

		/**
		 * Gets all the items in the deposit box matching any of the provided IDs.
		 *
		 * @param ids The IDs of the item to find.
		 * @return <tt>Item</tt> array of the matching deposit box items.
		 */
		public static Item[] getItems(int... ids) {
			if (!isOpen())
				return new Item[0];
			LinkedList<Item> out = new LinkedList<Item>();
			for (Item item : getItems()) {
				for (int id : ids) {
					if (item.getId() == id) {
						out.add(item);
					}
				}
			}
			return out.toArray(new Item[out.size()]);
		}

		/**
		 * Checks whether or not deposit box contains the provided item ID.
		 *
		 * @param id The item ID to check for.
		 * @return <tt>true</tt> if deposit box contains an item with the ID provided; otherwise <tt>false</tt>.
		 */
		public static boolean contains(int id) {
			return getItem(id) != null;
		}

		/**
		 * Checks whether or not deposit box contains at least one of the provided item IDs.
		 *
		 * @param ids The item IDs to check for.
		 * @return <tt>true</tt> if deposit box contains an item with one of the IDs provided; otherwise <tt>false</tt>.
		 */
		public static boolean containsOneOf(int... ids) {
			if (!isOpen())
				return false;
			for (Item i : getItems()) {
				for (int id : ids) {
					if (i.getId() == id) {
						return true;
					}
				}
			}
			return false;
		}

		/**
		 * Checks whether or not the deposit box contains all of the provided item IDs.
		 *
		 * @param ids The item IDs to check for.
		 * @return <tt>true</tt> if the deposit box contains all of the item IDs provided; otherwise <tt>false</tt>.
		 */
		public static boolean containsAll(int... ids) {
			if (!isOpen())
				return false;

			Item[] items = getItems();

			outer:
			for (int id : ids) {
				for (Item item : items) {
					if (item.getId() == id) {
						continue outer;
					}
				}
				return false;
			}
			return true;
		}

		/**
		 * Deposit everything your player has equipped.
		 *
		 * @return <tt>true</tt> on success.
		 */
		public static boolean depositAllEquipped() {
			return isOpen() && getWidget().getComponent(BUTTON_DEPOSIT_BOX_DEPOSIT_WORN).click();
		}

		/**
		 * Deposits everything your familiar is carrying.
		 *
		 * @return <tt>true</tt> on success
		 */
		public static boolean depositAllFamiliar() {
			return isOpen() && getWidget().getComponent(BUTTON_DEPOSIT_BOX_DEPOSIT_BEAST).click();
		}

		/**
		 * Deposits all items.
		 *
		 * @return <tt>true</tt> on success.
		 */
		public static boolean depositAll() {
			if (isOpen() && getWidget().getComponent(BUTTON_DEPOSIT_BOX_DEPOSIT_CARRIED).click())
				for (int i = 0; i < 3000; i += 20) {
					if (getCount(false) == 0) {
						return true;
					}
					Task.sleep(20);
				}
			return false;
		}

		/**
		 * Checks whether or not the deposit box is open.
		 *
		 * @return <tt>true</tt> if the deposit box widget is open; otherwise
		 *         <tt>false</tt>.
		 */
		public static boolean isOpen() {
			return getWidget().isValid();
		}

		/**
		 * Closes the deposit box widget.
		 *
		 * @return <tt>true</tt> if the deposit box widget is no longer open.
		 */
		public static boolean close() {
			if (isOpen()) {
				// how to check: check the tab and when it appears again then we're closed, probably inventory
				if (getWidget().getComponent(BUTTON_DEPOSIT_BOX_CLOSE).click()) {
					for (int i = 0; i < 10 && Game.getCurrentTab() != Game.TAB_INVENTORY; i++) {
						Task.sleep(100, 200);
					}
				}
				if (!isOpen()) {
					return true;
				}
			}
			return !isOpen();
		}

		/**
		 * Opens one of the supported deposit boxes nearby. If they are not nearby,
		 * and they are not null, it will automatically walk to the closest one.
		 *
		 * @return <tt>true</tt> if the deposit box was opened; otherwise <tt>false</tt>.
		 */
		public static boolean open() {
			try {
				if (!isOpen()) {
					if (Menu.isOpen()) {
						Mouse.moveSlightly();
						Task.sleep(Random.nextInt(20, 30));
					}
					GameObject depositBox = Objects.getNearest(DEPOSIT_BOXES);
					if (depositBox != null) {
						if (!Calculations.isTileOnScreen(depositBox.getLocation())) {
							Walking.getTileOnMap(depositBox.getLocation()).clickOnMap();
						} else if (depositBox.interact("Deposit")) {
							int count = 0;
							while (!isOpen() && ++count < 10) {
								Task.sleep(200, 400);
								if (Players.getLocal().isMoving()) {
									count = 0;
								}
							}
						}
					}
				}
				return isOpen();
			} catch (final Exception e) {
				e.printStackTrace();
				return false;
			}
		}
	}

}
