package noeffex.states;

import java.util.concurrent.CopyOnWriteArrayList;

/**
 * A container for a group (Or branch) of states
 * */

public abstract class StateGroup extends StateNode {
	private final CopyOnWriteArrayList<StateNode> children = new CopyOnWriteArrayList<StateNode>();
	private volatile StateNode currentChild = null;

	/**
	 * The preset activate to handle the childrens' activation
	 * 
	 * @return True on start, false on don't
	 * */

	public final boolean activate() {
		if (activateGroup()) {
			if (children.size() == 0) {
				StateNode[] childrenArray = getChildren();
				for (int idx = 0; idx < childrenArray.length; idx++) {
					StatePlugin plugin = childrenArray[idx].getClass().getAnnotation(StatePlugin.class);
					if (plugin != null) {
						// MinerMethods.log("Loading " + toString() + " - " + plugin.name());
					}
					children.add(childrenArray[idx]);
				}
				/* Class<?>[] childrenArray = getChildren();
				for (Class<?> child : childrenArray) {
					try {
						StatePlugin plugin = child.getAnnotation(StatePlugin.class);
						if (plugin != null) {
							MinerMethods.log("Loading " + toString() + " - " + plugin.name());
						}
						if ((child.getModifiers() & Modifier.STATIC) != 0) {
							children.add(AbstractState.class.cast(child.newInstance()));
						} else {
							Constructor<?> constructor = child.getDeclaredConstructor(getClass());
							if (constructor != null) {
								AbstractState state = (AbstractState) constructor.newInstance(this);
								children.add(state);
							} else {
								MinerMethods.log("Could not load " + Arrays.toString(child.getDeclaredConstructors()));
							}
						}
					} catch (Exception e) {
						e.printStackTrace();
					}
				} */
			}
			for (int i = 0; i < children.size(); i++) {
				StateNode child = children.get(i);
				if (child != null && child.activate()) {
					currentChild = child;
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * The preset execute to handle each of it's children
	 * */

	public final void execute() {
		if (currentChild != null && !currentChild.isActive() && currentChild.activate()) {
			getContainer().submit(currentChild);
			try {
				currentChild.join();
			} catch (final Exception e) { }
		} else {
			for (int i = 0; i < children.size(); i++) {
				StateNode child = children.get(i);
				if (child != null && child.activate()) {
					currentChild = child;
					getContainer().submit(child);
					try {
						child.join();
					} catch (final Exception e) { }
				}
			}
		}
	}
	
	/**
	 * Get the name of the group (Returns actual class if nothing)
	 * 
	 * @return The name if any
	 * */
	
	public final String toString() {
		StatePlugin plugin = getClass().getAnnotation(StatePlugin.class);
		if (plugin != null) {
			return plugin.name();
		} else {
			return getClass().toString();
		}
	}

	/**
	 * The preset getPlugin to handle children plugins
	 * 
	 * @return The plugin
	 * */

	public final StatePlugin getPlugin() {
		if (currentChild != null) {
			if (currentChild instanceof StateGroup) {
				return ((StateGroup) currentChild).getPlugin();
			} else {
				return currentChild.getClass().getAnnotation(StatePlugin.class);
			}
		} else {
			return null;
		}
	}

	/**
	 * Get the children
	 * 
	 * @return the children
	 * */

	protected abstract StateNode[] getChildren();

	/**
	 * The activation that activates the group children
	 * 
	 * @return true on activate, false on don't
	 * */

	protected abstract boolean activateGroup();
}
