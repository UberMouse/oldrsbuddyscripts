package noeffex.states;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;

public class StateManager {

	private volatile StateNode currentState = null;
	private volatile Class<?>[] stateClasses = null;
	private final Object stateLock = new Object();
	private final CopyOnWriteArrayList<StateNode> states = new CopyOnWriteArrayList<StateNode>();

	public StateManager(final Class<?>[] classes) {
		stateClasses = classes;
	}

	/**
	 * Generate the state classes into context ctx
	 * 
	 * @param classes the classes to use
	 * */

	private void generateClasses(final Class<?>[] classes) {
		for (final Class<?> state : classes) {
			try {
				StateNode currentState = (StateNode) state.newInstance();
				states.add(currentState);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void initClasses(final Class<?>[] classes) {
		generateClasses(classes);
	}

	/**
	 * Get the state to execute - caches running states and the whole nine yars
	 * 
	 * @return The state to run, if none then null
	 * */

	public StateNode getState() {
		synchronized (stateLock) {
			if (currentState != null && currentState.isActive()) {
				return null;
			} else {
				for (int i = 0; i < states.size(); i++) {
					StateNode state = states.get(i);
					if (state != null && state.activate()) {
						currentState = state;
						return state;
					}
				}
			}
			return null;
		}
	}

	/**
	 * Get the running plugin w/ context
	 *
	 * @return The running plugin if any
	 * */

	public StatePlugin getRunningPlugin() {
		if (currentState != null) {
			return currentState.getPlugin();
		} else {
			return null;
		}
	}

	/**
	 * Get the status (Idling if null)
	 *
	 * @return The status
	 * */

	public String getStatus() {
		StatePlugin plugin = getRunningPlugin();
		if (plugin != null) {
			return plugin.name();
		} else {
			return "Idling";
		}
	}
}
