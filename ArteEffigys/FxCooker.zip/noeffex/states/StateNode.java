package noeffex.states;

import com.rsbuddy.script.task.Task;

public abstract class StateNode extends Task {
	protected int index = -1;
	
	public abstract boolean activate();
	protected abstract void execute();
	
	/**
	 * Get the plugin of the current running StatePlugin
	 * */
	
	public StatePlugin getPlugin() {
		return getClass().getAnnotation(StatePlugin.class);
	}
	
	/**
	 * Return whether or not the current state should be executed concurrently
	 * 
	 * @return True if concurrent, false if not
	 * */
	
	public boolean isConcurrent() {
		return true;
	}
}

