package noeffex.utils;

import java.util.concurrent.ConcurrentHashMap;

import com.rsbuddy.script.methods.Skills;

public class ExpTracker {

	private final ConcurrentHashMap<Integer, LevelExpPair> expStart = new ConcurrentHashMap<Integer, LevelExpPair>();

	public ExpTracker() {
		track(Skills.COOKING);//we can add MOAR
	}

	public void track(final int skill) {
		expStart.put(skill, new LevelExpPair(0, 0));
	}

	public int getExpGained(final int skill) {
		LevelExpPair pair = expStart.get(skill);
		if (pair != null) {
			if (pair.exp <= 0) {
				return (pair.exp = Skills.getCurrentExp(skill));
			} else {
				return Skills.getCurrentExp(skill) - pair.exp;
			}
		}
		return -1;
	}

	public int getLevelGained(final int skill) {
		LevelExpPair pair = expStart.get(skill);
		if (pair != null) {
			if (pair.level <= 0) {
				return (pair.level = Skills.getCurrentLevel(skill));
			} else {
				return Skills.getCurrentLevel(skill) - pair.level;
			}
		}
		return -1;
	}

	class LevelExpPair {
		int exp;
		int level;
		public LevelExpPair(final int exp, final int level) {
			this.exp = exp;
			this.level = level;
		}
	}
}
