package noeffex.utils;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URL;
import java.util.Arrays;
import java.util.zip.GZIPInputStream;

import javax.imageio.ImageIO;

import com.rsbuddy.script.methods.Environment;

public class ResourceManager {

	public static String baseDir(String url) {
		String[] paths = url.split("/");
		return paths[paths.length - 1];
	}

	public static byte[] downloadFile(String url) {
		try {
			BufferedInputStream in = new BufferedInputStream(
					new URL(url).openStream());
			ByteArrayOutputStream bos = new ByteArrayOutputStream();
			byte data[] = new byte[10024];
			while ((in.read(data)) >= 0) {
				bos.write(data);
				Arrays.fill(data, (byte) 0);
			}
			bos.close();
			in.close();
			return bos.toByteArray();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new byte[0];
	}

	public static void writeFile(File file, byte[] data) {
		try {
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(data);
			fos.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static BufferedImage getImage(byte[] data) {
		try {
			return ImageIO.read(new GZIPInputStream(new ByteArrayInputStream(data)));
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static BufferedImage getImage(String url, String fileName) {
		try {
			File cachedImage = new File(Environment.getStorageDirectory() + File.separator + fileName);
			if (!cachedImage.exists()) {
				cachedImage.createNewFile();
				byte[] img = downloadFile(url);
				writeFile(cachedImage, img);
				cachedImage = new File(Environment.getStorageDirectory() + File.separator + fileName);
			}
			return ImageIO.read(cachedImage);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static BufferedImage getImage(String url) {
		return getImage(url, baseDir(url));
	}
}