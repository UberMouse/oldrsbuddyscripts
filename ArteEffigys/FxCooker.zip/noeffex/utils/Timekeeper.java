package noeffex.utils;

public class Timekeeper {
	public long startTime = 0;
	public long pausedTime = 0;
	public long pausedTemp = 0;
	public long state = 0;

	public Timekeeper() {
		startTime = System.currentTimeMillis();
	}

	public long getMillis() {
		return System.currentTimeMillis() - startTime - pausedTime;
	}

	public long getSeconds() {
		return this.getMillis() / 1000;
	}

	public long getMinutes() {
		return this.getSeconds() / 60;
	}

	public long getHours() {
		return this.getMinutes() / 60;
	}

	public String getRuntimeString() {
		long HoursRan = this.getHours();
		long MinutesRan = this.getMinutes();
		long SecondsRan = this.getSeconds();
		MinutesRan = MinutesRan % 60;
		SecondsRan = SecondsRan % 60;
		return HoursRan + ":" + MinutesRan + ":" + SecondsRan;
	}

	public void setPaused() {
		state = 1;
		pausedTemp = System.currentTimeMillis();
	}

	public long setResumed() {
		state = 0;
		return (pausedTime += (System.currentTimeMillis() - pausedTemp));
	}

	public long calcPerHour(final long i) {
		return calcPerHour((double) i);
	}

	public long calcPerHour(final double i) {
		double elapsed_millis = this.getMillis();
		return (long) ((i / elapsed_millis) * 3600000);
	}

	public double calcPerSecond(final long i) {
		double expToDouble = (double) i;
		double elapsed_millis = this.getMillis();
		return (expToDouble / elapsed_millis) * 1000;
	}
}
